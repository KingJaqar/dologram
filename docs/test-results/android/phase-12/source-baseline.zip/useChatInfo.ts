/**
 * Data for AND-12 (M2-07, D-91).
 *
 * One cache read per reload, repeated when the sync engine merges rows and when the screen regains
 * focus. A chat that is not cached (removed, or not synced yet) reports `notFound` so the screen can
 * offer Retry, which runs a resync first.
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import { useFocusEffect } from 'expo-router';
import { buildChatInfo, type ChatInfoModel } from '@dologram/shared';
import { useAuth } from '../auth/AuthProvider';
import { getLocalDatabase } from '../queue/db';
import { subscribeCacheChange } from '../sync/cacheEvents';
import { resyncNow } from '../sync/lifecycle';
import { loadChatInfoSource } from './infoQuery';

export type ChatInfoData = {
  loading: boolean;
  error: boolean;
  /** Cached chat info, or null when the chat is not in the cache. */
  info: ChatInfoModel | null;
  reload: () => Promise<void>;
  /** Resyncs and reloads; used by Retry and after a membership change. */
  refresh: () => Promise<void>;
};

type Loaded = { chatId: string; info: ChatInfoModel | null };

export function useChatInfo(chatId: string | undefined): ChatInfoData {
  const { session } = useAuth();
  const userId = session?.user.id ?? null;

  const [loaded, setLoaded] = useState<Loaded | null>(null);
  const [error, setError] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const inflight = useRef(false);

  const reload = useCallback(async () => {
    if (!chatId || !userId) return;
    if (inflight.current) return;
    inflight.current = true;
    try {
      const db = await getLocalDatabase();
      const source = await loadChatInfoSource(db, chatId);
      setLoaded({
        chatId,
        info:
          source.chat === null
            ? null
            : buildChatInfo({
                chat: source.chat,
                members: source.members,
                profiles: source.profiles,
                userId,
              }),
      });
      setError(false);
    } catch {
      setError(true);
    } finally {
      inflight.current = false;
    }
  }, [chatId, userId]);

  useEffect(() => subscribeCacheChange(() => void reload()), [reload]);

  useFocusEffect(
    useCallback(() => {
      void reload();
    }, [reload]),
  );

  const refresh = useCallback(async () => {
    if (refreshing) return;
    setRefreshing(true);
    try {
      await resyncNow();
    } catch {
      // A failed resync keeps the cached chat; Retry stays available.
    } finally {
      setRefreshing(false);
      await reload();
    }
  }, [refreshing, reload]);

  const info = loaded !== null && loaded.chatId === chatId ? loaded.info : null;

  return {
    loading: loaded === null && !error,
    error,
    info,
    reload,
    refresh,
  };
}
