/**
 * Foreground delivery worker (LS-3, LS-7, D-77, D-109, D-117, M2-03).
 *
 * It attempts delivery on every connectivity change and on the D-27 timer, only while the app is
 * in the foreground and the device reports a connection. Queued items send on the next open; the
 * worker never runs in the background.
 */
import { AppState, type AppStateStatus } from 'react-native';
import { File } from 'expo-file-system';
import {
  config,
  classifyError,
  createQueueRunner,
  insertMessageMedia,
  insertMessage,
  uploadAttachment,
  type DeliveryResult,
  type QueueItem,
  type QueueRunner,
} from '@dologram/shared';
import { supabase } from '../lib/supabase';
import { subscribeNetState } from '../net/netState';
import { cleanupSentQueueItems, getQueueCore, setActiveRunner } from './localQueue';
import { notifyQueueChange } from './events';
import { uploadMobileAttachment } from './mediaUploader';

export type QueueWorkerHandle = { stop: () => void };

/**
 * The message-row insert of M2-03. `message_id` is the client-generated id, so a retry of a stored
 * row is rejected with 23505, which is a delivery (LS-8) and not a failure.
 */
export async function deliverQueueItem(item: QueueItem): Promise<DeliveryResult> {
  const { error } = await insertMessage(supabase, {
    message_id: item.temp_id,
    chat_id: item.chat_id,
    sender_id: item.payload.sender_id,
    content: item.payload.content,
    reply_to: item.payload.reply_to,
    attachment_count: item.payload.attachment_count,
  });

  if (!error) {
    return deliverAttachments(item);
  }
  if (error.kind === 'delivered') return deliverAttachments(item);
  return { error, rowStored: false };
}

async function deliverAttachments(item: QueueItem): Promise<DeliveryResult> {
  for (const attachment of item.payload.attachments) {
    let body: ArrayBuffer | undefined;
    try {
      body = attachment.size_bytes > config.media.tusThresholdBytes
        ? undefined
        : await new File(attachment.local_uri).arrayBuffer();
    } catch (error) {
      return { error: classifyError(error), rowStored: true };
    }
    const uploaded = await uploadAttachment(supabase, {
      chatId: item.chat_id,
      mediaId: attachment.media_id,
      mediaType: attachment.media_type,
      mime: attachment.mime,
      sizeBytes: attachment.size_bytes,
      body,
      resumableUpload: (options) => uploadMobileAttachment({
        uri: attachment.local_uri,
        mime: options.mime,
        sizeBytes: attachment.size_bytes,
        bucket: options.bucket,
        path: options.path,
      }),
    });
    if (uploaded.error) return { error: uploaded.error, rowStored: true };

    const media = await insertMessageMedia(supabase, {
      mediaId: attachment.media_id,
      messageId: item.temp_id,
      mediaType: attachment.media_type,
      compressed: attachment.compressed,
    });
    if (media.error) return { error: media.error, rowStored: true };
  }
  return { error: null, rowStored: true };
}

export function startQueueWorker(): QueueWorkerHandle {
  let stopped = false;
  // NetInfo answers soon after subscribing, so the worker waits for that first answer rather than
  // assuming a connection and counting an attempt while offline (D-77).
  let connected = false;
  let foreground = AppState.currentState === 'active';
  let runner: QueueRunner | null = null;

  const timer = setInterval(() => {
    if (!stopped && foreground && connected && runner) {
      void runner.drain();
    }
  }, config.queue.timerMs);

  const unsubscribeNet = subscribeNetState((state) => {
    const wasConnected = connected;
    connected = state.isConnected;
    if (stopped || !runner) return;
    if (connected && !wasConnected) {
      // D-77: a returning connection makes every queued item due at once.
      void runner.handleConnectivity(true);
    }
  });

  const appStateSubscription = AppState.addEventListener('change', (next: AppStateStatus) => {
    const wasForeground = foreground;
    foreground = next === 'active';
    if (!stopped && foreground && !wasForeground && connected && runner) {
      void runner.drain();
    }
  });

  getQueueCore()
    .then((core) => {
      if (stopped) return;
      runner = createQueueRunner({
        core,
        deliver: deliverQueueItem,
        onAttempt: ({ outcome }) => {
          notifyQueueChange();
          if (outcome.status === 'sent') {
            void cleanupSentQueueItems().catch((error: unknown) => {
              console.error('DoloGram queue: sent attachment cleanup failed.', error);
            });
          }
        },
      });
      setActiveRunner(runner);
    })
    .catch((error: unknown) => {
      // The queue is unusable without its database; report it instead of failing silently.
      console.error('DoloGram queue: the local database could not be opened.', error);
    });

  return {
    stop(): void {
      stopped = true;
      clearInterval(timer);
      unsubscribeNet();
      appStateSubscription.remove();
      setActiveRunner(null);
    },
  };
}
