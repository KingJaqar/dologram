/**
 * Chat list data for AND-03 and AND-04 (M2-08, F2, D-44, D-94).
 *
 * One read of the local cache feeds both screens and the "Archived (n)" row. The list reloads when
 * the sync engine merges rows (a Realtime event or a finished pass), when the screen regains focus
 * and on pull to refresh, which runs a resync (6.4).
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useFocusEffect } from 'expo-router';
import { buildChatList, type ChatListItem, type ChatListSourceRow } from '@dologram/shared';
import { useAuth } from '../auth/AuthProvider';
import { getLocalDatabase } from '../queue/db';
import { subscribeCacheChange } from '../sync/cacheEvents';
import { resyncNow } from '../sync/lifecycle';
import { loadChatListRows } from './query';

export type ChatListData = {
  /** AND-03 rows in D-94 order; archived chats are left out. */
  active: ChatListItem[];
  /** AND-04 rows in D-94 order. */
  archived: ChatListItem[];
  /** True until the first read of the cache resolves. */
  loading: boolean;
  /** A read failed; the last successful rows are still shown when there are any. */
  error: boolean;
  /** True while a pull-to-refresh resync runs. */
  refreshing: boolean;
  reload: () => Promise<void>;
  refresh: () => Promise<void>;
};

type LoadedRows = { userId: string; rows: ChatListSourceRow[] };

export function useChatList(): ChatListData {
  const { session } = useAuth();
  const userId = session?.user.id ?? null;

  const [loaded, setLoaded] = useState<LoadedRows | null>(null);
  const [error, setError] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const inflight = useRef(false);

  const reload = useCallback(async () => {
    if (!userId || inflight.current) return;
    inflight.current = true;
    try {
      const db = await getLocalDatabase();
      const rows = await loadChatListRows(db, userId);
      setLoaded({ userId, rows });
      setError(false);
    } catch {
      setError(true);
    } finally {
      inflight.current = false;
    }
  }, [userId]);

  // A mounted screen loads through its focus effect; later cache writes reload it too.
  useEffect(() => subscribeCacheChange(() => void reload()), [reload]);

  useFocusEffect(
    useCallback(() => {
      void reload();
    }, [reload]),
  );

  const refresh = useCallback(async () => {
    setRefreshing(true);
    try {
      await resyncNow();
    } catch {
      // A failed resync keeps the cached list; the next foreground pass or pull retries.
    } finally {
      setRefreshing(false);
      await reload();
    }
  }, [reload]);

  // Rows of a previous account are never shown while the new account loads.
  const rows = loaded !== null && loaded.userId === userId ? loaded.rows : null;

  // Both lists are built from one read and one reference time, so a row cannot show two labels.
  const lists = useMemo(() => {
    if (rows === null || userId === null) {
      return { active: [] as ChatListItem[], archived: [] as ChatListItem[] };
    }
    const now = new Date();
    return {
      active: buildChatList(rows, { userId, now }),
      archived: buildChatList(rows, { userId, now, archived: true }),
    };
  }, [rows, userId]);

  return {
    active: lists.active,
    archived: lists.archived,
    loading: rows === null && !error,
    error,
    refreshing,
    reload,
    refresh,
  };
}
