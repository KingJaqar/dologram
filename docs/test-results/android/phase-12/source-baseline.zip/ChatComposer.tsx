/** CMP-10: the Phase 9 text composer. Media actions remain present for later attachment phases. */
import React from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { config, strings } from '@dologram/shared';
import { useTheme } from '../theme/ThemeProvider';
import { textStyle } from '../theme/typography';
import { Icon } from './Icon';

export type ChatComposerProps = {
  value: string;
  onChangeText: (value: string) => void;
  onSend: () => void;
  sending?: boolean;
  replyPreview?: { senderName: string; content: string; deleted: boolean };
  editing?: boolean;
  onCancelMode?: () => void;
};

export function ChatComposer({ value, onChangeText, onSend, sending = false, replyPreview, editing = false, onCancelMode }: ChatComposerProps) {
  const theme = useTheme();
  const c = theme.colors;
  const length = Array.from(value).length;
  const canSend = value.trim().length > 0 && length <= config.message.maxChars && !sending;
  const showCounter = length >= config.message.counterFromChars;
  const handleChangeText = (next: string) => {
    // TextInput maxLength counts native string units; the contract counts Unicode code points.
    onChangeText(Array.from(next).slice(0, config.message.maxChars + 1).join(''));
  };

  return (
    <View style={[styles.container, { backgroundColor: c.bg.chat }]}>
      {replyPreview || editing ? (
        <View style={[styles.modeBar, { backgroundColor: c.bg.surface, borderLeftColor: c.brand.primary }]}>
          <View style={styles.modeCopy}>
            <Text style={[textStyle(theme.typeTokens.labelMd), { color: c.brand.primary }]}>{editing ? strings.chat.editing : strings.chat.replyTo(replyPreview?.senderName ?? '')}</Text>
            {!editing && replyPreview ? <Text style={[textStyle(theme.typeTokens.bodySm), { color: c.text.secondary }]} numberOfLines={1}>{replyPreview.deleted ? strings.chat.deletedReply : replyPreview.content}</Text> : null}
          </View>
          <Pressable onPress={onCancelMode} accessibilityRole="button" accessibilityLabel="Cancel reply" style={styles.cancelMode}>
            <Icon name="nav.close" size="sm" color={c.text.secondary} accessibilityLabel="" />
          </Pressable>
        </View>
      ) : null}
      {showCounter ? (
        <Text style={[textStyle(theme.typeTokens.labelMd), styles.counter, { color: length > config.message.maxChars ? c.error.text : c.text.muted }]}>
          {length} / {config.message.maxChars}
        </Text>
      ) : null}
      <View style={[styles.pill, { backgroundColor: c.bg.surface, borderRadius: length > 80 ? theme.radius.xl : theme.radius.full }]}>
        <Pressable
          disabled
          accessibilityRole="button"
          accessibilityLabel="Camera"
          style={styles.iconButton}
        >
          <Icon name="action.camera" size="md" color={c.text.muted} accessibilityLabel="" />
        </Pressable>
        <TextInput
          value={value}
          onChangeText={handleChangeText}
          placeholder={editing ? strings.chat.editPlaceholder : 'Message'}
          placeholderTextColor={c.text.muted}
          multiline
          numberOfLines={6}
          textAlignVertical="top"
          autoCorrect
          style={[textStyle(theme.typeTokens.bodyLg), styles.input, { color: c.text.primary }]}
          accessibilityLabel="Message"
        />
        {canSend ? (
          <Pressable
            onPress={onSend}
            accessibilityRole="button"
            accessibilityLabel="Send"
            style={({ pressed }) => [styles.send, { opacity: pressed ? 0.7 : 1 }]}
          >
            <Text style={[textStyle(theme.typeTokens.labelLg), { color: c.brand.primary }]}>{editing ? strings.chat.save : 'Send'}</Text>
          </Pressable>
        ) : (
          <View style={styles.trailingActions}>
            <Pressable disabled accessibilityRole="button" accessibilityLabel="Record voice note" style={styles.iconButton}>
              <Icon name="action.microphone" size="md" color={c.text.muted} accessibilityLabel="" />
            </Pressable>
            <Pressable disabled accessibilityRole="button" accessibilityLabel="Gallery" style={styles.iconButton}>
              <Icon name="action.gallery" size="md" color={c.text.muted} accessibilityLabel="" />
            </Pressable>
            <Pressable disabled accessibilityRole="button" accessibilityLabel="Attach" style={styles.iconButton}>
              <Icon name="action.attach" size="md" color={c.text.muted} accessibilityLabel="" />
            </Pressable>
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { paddingHorizontal: 8, paddingTop: 8, paddingBottom: 8 },
  modeBar: { minHeight: 48, borderLeftWidth: 3, paddingHorizontal: 10, flexDirection: 'row', alignItems: 'center', marginBottom: 6, borderRadius: 6 },
  modeCopy: { flex: 1, gap: 2 },
  cancelMode: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  counter: { alignSelf: 'flex-end', marginRight: 12, marginBottom: 3 },
  pill: { minHeight: 44, maxHeight: 180, padding: 6, flexDirection: 'row', alignItems: 'flex-end' },
  input: { flex: 1, minHeight: 32, maxHeight: 156, paddingHorizontal: 8, paddingVertical: 6 },
  iconButton: { width: 32, height: 32, alignItems: 'center', justifyContent: 'center' },
  trailingActions: { flexDirection: 'row', alignItems: 'center' },
  send: { height: 40, justifyContent: 'center', paddingHorizontal: 8 },
});
