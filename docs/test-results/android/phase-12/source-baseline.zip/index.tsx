/** AND-05 chat screen (M2-09, M2-11, M2-12, F3, F6, F7, D-57, D-92, D-118, D-143). */
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  RefreshControl,
  StyleSheet,
  Text,
  View,
  type ListRenderItem,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import {
  addReaction,
  config,
  dgTrim,
  editMessage,
  listChatMembers,
  setReactionRemoved,
  softDeleteMessage,
  strings,
  updateOwnMember,
  validateMessageText,
} from '@dologram/shared';
import * as Clipboard from 'expo-clipboard';
import { supabase } from '../../../src/lib/supabase';
import { useAuth } from '../../../src/auth/AuthProvider';
import { useNetState } from '../../../src/net/netState';
import { useTheme } from '../../../src/theme/ThemeProvider';
import { useToast } from '../../../src/components/Toast';
import { TopBar } from '../../../src/components/TopBar';
import { IconButton } from '../../../src/components/Button';
import { OfflineBanner } from '../../../src/components/ConnectionBanner';
import { EmptyState } from '../../../src/components/EmptyState';
import { DateSeparator, JumpToBottom, UnreadDivider } from '../../../src/components/DateSeparator';
import { ChatComposer } from '../../../src/components/ChatComposer';
import { MessageBubble, type BubbleStatus } from '../../../src/components/MessageBubble';
import { MessageFocusOverlay } from '../../../src/components/MessageFocusOverlay';
import { Dialog } from '../../../src/components/Dialog';
import { loadCachedReaction, loadChatSnapshot, mergeChatSnapshots, type ChatMessageItem, type ChatScreenSnapshot } from '../../../src/chat/query';
import { cacheMembers, flushPendingReadStates, markChatRead, type ReadStateSender } from '../../../src/chat/readState';
import { startChatRealtime, type ChatRealtimeHandle } from '../../../src/chat/realtime';
import { getLocalDatabase } from '../../../src/queue/db';
import { discardQueueItem, enqueueTextMessage, retryQueueItem } from '../../../src/queue/localQueue';
import { subscribeQueueChange } from '../../../src/queue/events';
import { notifyCacheChange, subscribeCacheChange } from '../../../src/sync/cacheEvents';
import { createSqliteCacheStore } from '../../../src/sync/cacheStore';

type TypingEntry = { name: string; expiresAt: number };

function resolvedParam(value: string | string[] | undefined): string {
  return typeof value === 'string' ? value : value?.[0] ?? '';
}

function dateLabel(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const day = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  const days = Math.round((today.getTime() - day.getTime()) / 86400000);
  const time = date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  if (days === 0) return `Today ${time}`;
  if (days === 1) return `Yesterday ${time}`;
  return `${date.toLocaleDateString([], { dateStyle: 'medium' })} ${time}`;
}

function shouldSeparate(previous: ChatMessageItem | undefined, current: ChatMessageItem): boolean {
  if (!previous) return true;
  const previousDate = new Date(previous.createdAt);
  const currentDate = new Date(current.createdAt);
  const gap = currentDate.getTime() - previousDate.getTime();
  return previousDate.toDateString() !== currentDate.toDateString() || gap >= 60 * 60 * 1000;
}

function maxDeliveredSeq(messages: readonly ChatMessageItem[]): number {
  return messages.reduce((max, message) => (message.seq === null ? max : Math.max(max, message.seq)), 0);
}

export default function ChatScreen() {
  const params = useLocalSearchParams<{ chatId?: string | string[] }>();
  const chatId = resolvedParam(params.chatId);
  const router = useRouter();
  const { session } = useAuth();
  const theme = useTheme();
  const net = useNetState();
  const toast = useToast();
  const userId = session?.user.id ?? '';
  const listRef = useRef<FlatList<ChatMessageItem>>(null);
  const realtimeRef = useRef<ChatRealtimeHandle | null>(null);
  const typingTimersRef = useRef<Map<string, ReturnType<typeof setTimeout>>>(new Map());
  const snapshotRef = useRef<ChatScreenSnapshot | null>(null);
  const lastTypingSentRef = useRef(0);
  const [snapshot, setSnapshot] = useState<ChatScreenSnapshot | null>(null);
  const [draft, setDraft] = useState('');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [loadingOlder, setLoadingOlder] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showTimeId, setShowTimeId] = useState<string | null>(null);
  const [typing, setTyping] = useState<Map<string, TypingEntry>>(new Map());
  const [atBottom, setAtBottom] = useState(true);
  const [focusMessage, setFocusMessage] = useState<ChatMessageItem | null>(null);
  const [replyTarget, setReplyTarget] = useState<ChatMessageItem | null>(null);
  const [editingMessage, setEditingMessage] = useState<ChatMessageItem | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<ChatMessageItem | null>(null);
  snapshotRef.current = snapshot;

  const refreshLatest = useCallback(async (showSpinner = false): Promise<void> => {
    if (!chatId || !userId) return;
    if (showSpinner) setRefreshing(true);
    try {
      const db = await getLocalDatabase();
      const next = await loadChatSnapshot(db, chatId, userId, { limit: config.list.pageSize });
      setSnapshot((current) => (current ? mergeChatSnapshots(current, next) : next));
      setError(null);
      setLoading(false);
    } catch (cause) {
      setLoading(false);
      setError(cause instanceof Error ? cause.message : strings.common.couldNotLoad);
    } finally {
      if (showSpinner) setRefreshing(false);
    }
  }, [chatId, userId]);

  const sendReadHint = useCallback(async (targetChatId: string, seq: number): Promise<boolean> => {
    if (targetChatId !== chatId) return false;
    return (await realtimeRef.current?.sendRead({ user_id: userId, last_read_seq: seq })) ?? false;
  }, [chatId, userId]);

  const sendReadState: ReadStateSender = useCallback(
    (targetChatId, seq) => updateOwnMember(supabase, targetChatId, userId, { last_read_seq: seq }),
    [userId],
  );

  const markRead = useCallback(async (nextSnapshot: ChatScreenSnapshot): Promise<void> => {
    const seq = maxDeliveredSeq(nextSnapshot.messages);
    if (!seq || !userId) return;
    const db = await getLocalDatabase();
    await markChatRead(db, chatId, userId, seq, net.isConnected, sendReadState, sendReadHint);
  }, [chatId, net.isConnected, sendReadHint, sendReadState, userId]);

  const updateTyping = useCallback((typingUserId: string, active: boolean) => {
    if (typingUserId === userId) return;
    setTyping((current) => {
      const next = new Map(current);
      const oldTimer = typingTimersRef.current.get(typingUserId);
      if (oldTimer) clearTimeout(oldTimer);
      if (!active) {
        next.delete(typingUserId);
        typingTimersRef.current.delete(typingUserId);
        return next;
      }
      const timer = setTimeout(() => {
        setTyping((latest) => {
          const cleared = new Map(latest);
          cleared.delete(typingUserId);
          return cleared;
        });
        typingTimersRef.current.delete(typingUserId);
      }, config.typing.hideAfterMs);
      typingTimersRef.current.set(typingUserId, timer);
      next.set(typingUserId, {
        name: snapshotRef.current?.messages.find((message) => message.senderId === typingUserId)?.senderName ?? strings.chatList.unknownMember,
        expiresAt: Date.now() + config.typing.hideAfterMs,
      });
      return next;
    });
  }, [userId]);

  useEffect(() => {
    const initialLoad = setTimeout(() => void refreshLatest(), 0);
    const unsubscribeCache = subscribeCacheChange(() => void refreshLatest());
    const unsubscribeQueue = subscribeQueueChange(() => void refreshLatest());
    return () => {
      clearTimeout(initialLoad);
      unsubscribeCache();
      unsubscribeQueue();
    };
  }, [refreshLatest]);

  useEffect(() => {
    if (!snapshot || !userId) return;
    const readTask = setTimeout(() => void markRead(snapshot).catch(() => undefined), 0);
    return () => clearTimeout(readTask);
  }, [markRead, snapshot, userId]);

  useEffect(() => {
    if (!chatId || !userId) return;
    const handle = startChatRealtime(chatId, {
      onTyping: (payload) => updateTyping(payload.user_id, payload.active),
      onRead: (payload) => {
        if (payload.user_id === userId) return;
        void getLocalDatabase()
          .then((db) => listChatMembers(supabase, chatId).then(async (result) => {
            if (!result.error && result.data) {
              await cacheMembers(db, result.data);
              await refreshLatest();
            }
          }))
          .catch(() => undefined);
      },
    });
    realtimeRef.current = handle;
    return () => {
      handle.stop();
      realtimeRef.current = null;
    };
  }, [chatId, refreshLatest, updateTyping, userId]);

  useEffect(() => {
    if (!net.isConnected || !userId) return;
    void getLocalDatabase()
      .then((db) => flushPendingReadStates(db, sendReadState, sendReadHint))
      .catch(() => undefined);
  }, [net.isConnected, sendReadHint, sendReadState, userId]);

  useEffect(() => () => {
    for (const timer of typingTimersRef.current.values()) clearTimeout(timer);
    typingTimersRef.current.clear();
  }, []);

  const typingLabel = useMemo(() => {
    const active = [...typing.values()];
    if (active.length === 0) return snapshot?.subtitle ?? '';
    if (snapshot?.chat.type === 'group') {
      return active.length === 1 ? strings.chat.typingOne(active[0]?.name ?? strings.chatList.unknownMember) : strings.chat.typingMany(active.length);
    }
    return 'typing...';
  }, [snapshot, typing]);

  const loadOlder = useCallback(async () => {
    if (!snapshot || loadingOlder || !snapshot.hasMoreBefore) return;
    const oldest = snapshot.messages.find((message) => message.seq !== null)?.seq;
    if (oldest === undefined || oldest === null) return;
    setLoadingOlder(true);
    try {
      const db = await getLocalDatabase();
      const older = await loadChatSnapshot(db, chatId, userId, { beforeSeq: oldest, limit: config.list.pageSize });
      setSnapshot((current) => current ? {
        ...current,
        messages: [...older.messages, ...current.messages.filter((message) => !older.messages.some((row) => row.messageId === message.messageId))],
        hasMoreBefore: older.hasMoreBefore,
      } : current);
    } catch {
      toast.showToast({ message: strings.common.couldNotLoad });
    } finally {
      setLoadingOlder(false);
    }
  }, [chatId, loadingOlder, snapshot, toast, userId]);

  const send = useCallback(async () => {
    const content = dgTrim(draft);
    if (!validateMessageText(content, 0).ok) return;
    const result = await enqueueTextMessage({ chatId, senderId: userId, content, replyTo: replyTarget?.messageId ?? null });
    if (!result.ok) {
      toast.showToast({ message: strings.queue.full });
      return;
    }
    setDraft('');
    setReplyTarget(null);
    await realtimeRef.current?.sendTyping({ user_id: userId, active: false });
    setTyping((current) => {
      const next = new Map(current);
      next.delete(userId);
      return next;
    });
    await refreshLatest();
    requestAnimationFrame(() => listRef.current?.scrollToEnd({ animated: true }));
  }, [chatId, draft, refreshLatest, replyTarget?.messageId, toast, userId]);

  const saveEdit = useCallback(async () => {
    if (!editingMessage) return;
    if (!net.isConnected) {
      toast.showToast({ message: strings.common.noConnection });
      return;
    }
    const content = dgTrim(draft);
    if (!validateMessageText(content, 0).ok) {
      toast.showToast({ message: strings.chat.deleteContentRequired });
      return;
    }
    const result = await editMessage(supabase, editingMessage.messageId, content);
    if (result.error || !result.data) {
      toast.showToast({ message: strings.common.couldNotLoad });
      return;
    }
    const db = await getLocalDatabase();
    await createSqliteCacheStore(db).upsertMessage(result.data);
    notifyCacheChange();
    setEditingMessage(null);
    setDraft('');
    await refreshLatest();
  }, [draft, editingMessage, net.isConnected, refreshLatest, toast]);

  const persistReaction = useCallback(async (reaction: Awaited<ReturnType<typeof addReaction>>['data']): Promise<void> => {
    if (!reaction) return;
    const db = await getLocalDatabase();
    await createSqliteCacheStore(db).upsertReaction(reaction);
    notifyCacheChange();
    await refreshLatest();
  }, [refreshLatest]);

  const toggleReaction = useCallback(async (item: ChatMessageItem, emoji: string) => {
    if (!net.isConnected) {
      toast.showToast({ message: strings.common.noConnection });
      return;
    }
    if (item.deletedAt !== null || item.pending) return;
    const ownReaction = item.reactions.find((reaction) => reaction.user_id === userId && reaction.emoji === emoji);
    if (!ownReaction && item.reactions.filter((reaction) => reaction.user_id === userId).length >= config.reactions.maxActivePerMessage) {
      toast.showToast({ message: strings.chat.reactionLimit });
      return;
    }
    const db = await getLocalDatabase();
    const result = ownReaction
      ? await setReactionRemoved(supabase, item.messageId, userId, emoji, true)
      : (await loadCachedReaction(db, item.messageId, userId, emoji))
        ? await setReactionRemoved(supabase, item.messageId, userId, emoji, false)
        : await addReaction(supabase, { message_id: item.messageId, user_id: userId, emoji });
    if (result.error || !result.data) {
      toast.showToast({ message: strings.common.couldNotLoad });
      return;
    }
    await persistReaction(result.data);
  }, [net.isConnected, persistReaction, toast, userId]);

  const copyMessage = useCallback(async (item: ChatMessageItem) => {
    if (!item.content) return;
    await Clipboard.setStringAsync(item.content);
    toast.showToast({ message: strings.chat.copied });
  }, [toast]);

  const confirmDelete = useCallback(async () => {
    if (!deleteTarget || !net.isConnected) return;
    const result = await softDeleteMessage(supabase, deleteTarget.messageId);
    if (result.error || !result.data) {
      toast.showToast({ message: strings.common.couldNotLoad });
      return;
    }
    const db = await getLocalDatabase();
    await createSqliteCacheStore(db).upsertMessage(result.data);
    notifyCacheChange();
    setDeleteTarget(null);
    await refreshLatest();
  }, [deleteTarget, net.isConnected, refreshLatest, toast]);

  const retry = useCallback(async (tempId: string) => {
    const result = await retryQueueItem(tempId);
    if (!result.ok) toast.showToast({ message: strings.common.couldNotLoad });
  }, [toast]);

  const discard = useCallback(async (tempId: string) => {
    const result = await discardQueueItem(tempId, net.isConnected);
    if (!result.ok) toast.showToast({ message: result.reason === 'offline' ? strings.common.noConnection : strings.common.couldNotLoad });
  }, [net.isConnected, toast]);

  const lastOwnMessageId = useMemo(() => {
    const own = snapshot?.messages.filter((message) => message.senderId === userId && message.pending === null) ?? [];
    return own[own.length - 1]?.messageId ?? null;
  }, [snapshot?.messages, userId]);

  const renderMessage: ListRenderItem<ChatMessageItem> = useCallback(({ item, index }) => {
    if (!snapshot) return null;
    const previous = snapshot.messages[index - 1];
    const isUnread = item.seq !== null && item.seq > snapshot.myLastReadSeq && item.senderId !== userId && item.deletedAt === null;
    const otherHasRead = snapshot.members.filter((member) => member.user_id !== userId).some((member) => item.seq !== null && member.last_read_seq >= item.seq);
    const status: BubbleStatus = item.pending ? null : item.messageId === lastOwnMessageId ? (otherHasRead ? 'seen' : 'sent') : null;
    return (
      <React.Fragment key={item.messageId}>
        {shouldSeparate(previous, item) ? <DateSeparator label={dateLabel(item.createdAt)} /> : null}
        {isUnread && (index === 0 || (snapshot.messages[index - 1]?.seq ?? 0) <= snapshot.myLastReadSeq) ? <UnreadDivider /> : null}
        <MessageBubble
          item={item}
          own={item.senderId === userId}
          userId={userId}
          status={status}
          showTime={showTimeId === item.messageId}
          onPress={() => setShowTimeId((current) => current === item.messageId ? null : item.messageId)}
          onLongPress={() => {
            if (item.deletedAt === null) setFocusMessage(item);
          }}
          onDoubleTap={() => {
            if (item.deletedAt === null) void toggleReaction(item, '❤️');
          }}
          onReactionPress={(emoji) => void toggleReaction(item, emoji)}
          reactionDisabled={!net.isConnected || item.deletedAt !== null}
          replyPreview={item.replyTo ? (() => {
            const parent = snapshot.messages.find((message) => message.messageId === item.replyTo);
            return parent ? { senderName: parent.senderName || strings.chatList.unknownMember, content: parent.content, deleted: parent.deletedAt !== null } : undefined;
          })() : undefined}
          onRetry={item.pending ? () => void retry(item.pending?.temp_id ?? '') : undefined}
          onDiscard={item.pending ? () => void discard(item.pending?.temp_id ?? '') : undefined}
          discardDisabled={!net.isConnected}
        />
      </React.Fragment>
    );
  }, [discard, lastOwnMessageId, net.isConnected, retry, showTimeId, snapshot, toggleReaction, userId]);

  if (!chatId || !userId) {
    return <EmptyState iconName="action.info" title={strings.chatInfo.unavailable} message={strings.chatInfo.unavailableBody} />;
  }

  return (
    <KeyboardAvoidingView style={[styles.container, { backgroundColor: theme.colors.bg.chat }]} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <TopBar
        title={snapshot?.title ?? 'Chat'}
        subtitle={typingLabel}
        onBack={() => router.back()}
        right={<IconButton iconName="action.info" accessibilityLabel="Chat info" onPress={() => router.push({ pathname: '/chat/[chatId]/info', params: { chatId } })} />}
      />
      {!net.isConnected ? <OfflineBanner /> : null}
      {loading && !snapshot ? (
        <View style={styles.center} accessibilityLabel="Loading messages"><ActivityIndicator color={theme.colors.brand.primary} /></View>
      ) : error && !snapshot ? (
        <View style={styles.center}>
          <Text style={[styles.error, { color: theme.colors.error.text }]}>{error}</Text>
          <Text onPress={() => void refreshLatest(true)} style={[styles.retry, { color: theme.colors.brand.primary }]} accessibilityRole="button">{strings.common.retry}</Text>
        </View>
      ) : (
        <>
          <FlatList
            ref={listRef}
            data={snapshot?.messages ?? []}
            renderItem={renderMessage}
            keyExtractor={(item) => item.messageId}
            contentContainerStyle={styles.listContent}
            onScroll={(event) => {
              const { contentOffset, contentSize, layoutMeasurement } = event.nativeEvent;
              setAtBottom(contentSize.height - (contentOffset.y + layoutMeasurement.height) < 80);
              if (contentOffset.y < 80) void loadOlder();
            }}
            scrollEventThrottle={100}
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => void refreshLatest(true)} tintColor={theme.colors.brand.primary} />}
            ListEmptyComponent={<EmptyState iconName="action.send" title={strings.chat.emptyTitle} message="Send the first message." />}
            accessibilityLabel="Messages"
          />
          {snapshot && !atBottom ? <View style={styles.jump}><JumpToBottom onPress={() => listRef.current?.scrollToEnd({ animated: true })} unreadCount={snapshot.unreadCount} /></View> : null}
          {loadingOlder ? <ActivityIndicator style={styles.olderSpinner} color={theme.colors.brand.primary} /> : null}
          <ChatComposer
            value={draft}
            onChangeText={(value) => {
              setDraft(value);
              if (net.isConnected && Date.now() - lastTypingSentRef.current >= config.typing.sendEveryMs) {
                lastTypingSentRef.current = Date.now();
                void realtimeRef.current?.sendTyping({ user_id: userId, active: true });
              }
            }}
            onSend={() => void (editingMessage ? saveEdit() : send())}
            editing={editingMessage !== null}
            replyPreview={replyTarget ? { senderName: replyTarget.senderName || strings.chatList.unknownMember, content: replyTarget.content, deleted: replyTarget.deletedAt !== null } : undefined}
            onCancelMode={() => {
              setReplyTarget(null);
              setEditingMessage(null);
              setDraft('');
            }}
          />
        </>
      )}
      <MessageFocusOverlay
        visible={focusMessage !== null}
        item={focusMessage}
        own={focusMessage?.senderId === userId}
        userId={userId}
        online={net.isConnected}
        discardDisabled={!net.isConnected}
        onClose={() => setFocusMessage(null)}
        onReact={(emoji) => {
          if (focusMessage) void toggleReaction(focusMessage, emoji);
          setFocusMessage(null);
        }}
        onReply={() => {
          if (focusMessage) setReplyTarget(focusMessage);
          setEditingMessage(null);
          setDraft('');
          setFocusMessage(null);
        }}
        onForward={() => {
          if (focusMessage) router.push({ pathname: '/forward', params: { sourceChatId: chatId, messageId: focusMessage.messageId } });
          setFocusMessage(null);
        }}
        onCopy={() => {
          if (focusMessage) void copyMessage(focusMessage);
          setFocusMessage(null);
        }}
        onEdit={() => {
          if (focusMessage) {
            setEditingMessage(focusMessage);
            setReplyTarget(null);
            setDraft(focusMessage.content);
          }
          setFocusMessage(null);
        }}
        onDelete={() => {
          if (focusMessage) setDeleteTarget(focusMessage);
          setFocusMessage(null);
        }}
        onRetry={() => {
          if (focusMessage?.pending) void retry(focusMessage.pending.temp_id);
          setFocusMessage(null);
        }}
        onDiscard={() => {
          if (focusMessage?.pending) void discard(focusMessage.pending.temp_id);
          setFocusMessage(null);
        }}
      />
      <Dialog
        visible={deleteTarget !== null}
        title={strings.chat.deleteConfirm}
        confirmLabel={strings.chat.delete}
        onConfirm={() => void confirmDelete()}
        onDismiss={() => setDeleteTarget(null)}
        destructive
      />
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  listContent: { paddingVertical: 12, flexGrow: 1 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24, gap: 12 },
  error: { textAlign: 'center', fontSize: 16 },
  retry: { fontSize: 16, fontWeight: '600' },
  jump: { position: 'absolute', right: 16, bottom: 76 },
  olderSpinner: { position: 'absolute', top: 68, alignSelf: 'center' },
});
