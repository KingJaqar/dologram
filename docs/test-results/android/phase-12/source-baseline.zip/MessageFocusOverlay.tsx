/** CMP-34 / AND-06: the Android message focus overlay. */
import React, { useEffect, useRef } from 'react';
import {
  Animated,
  Modal,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { config, strings } from '@dologram/shared';
import { useTheme } from '../theme/ThemeProvider';
import { textStyle } from '../theme/typography';
import { Icon } from './Icon';
import type { ChatMessageItem } from '../chat/query';

export type MessageFocusOverlayProps = {
  visible: boolean;
  item: ChatMessageItem | null;
  own: boolean;
  userId: string;
  online: boolean;
  discardDisabled: boolean;
  onClose: () => void;
  onReact: (emoji: string) => void;
  onReply: () => void;
  onForward: () => void;
  onCopy: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onRetry: () => void;
  onDiscard: () => void;
};

type ActionRowProps = {
  label: string;
  iconName: string;
  disabled?: boolean;
  reason?: string;
  destructive?: boolean;
  onPress: () => void;
};

function ActionRow({ label, iconName, disabled = false, reason, destructive = false, onPress }: ActionRowProps) {
  const theme = useTheme();
  const c = theme.colors;
  const labelColor = destructive ? c.error.text : c.text.primary;
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      accessibilityRole="button"
      accessibilityLabel={label}
      accessibilityState={{ disabled }}
      style={({ pressed }) => [styles.actionRow, { backgroundColor: pressed && !disabled ? c.bg.pressed : 'transparent', opacity: disabled ? 0.5 : 1 }]}
    >
      <View style={styles.actionCopy}>
        <Text style={[textStyle(theme.typeTokens.bodyLg), { color: labelColor }]}>{label}</Text>
        {reason ? <Text style={[textStyle(theme.typeTokens.bodySm), { color: c.text.secondary }]}>{reason}</Text> : null}
      </View>
      <Icon name={iconName} size="md" color={labelColor} accessibilityLabel="" />
    </Pressable>
  );
}

export function MessageFocusOverlay({
  visible,
  item,
  own,
  userId,
  online,
  discardDisabled,
  onClose,
  onReact,
  onReply,
  onForward,
  onCopy,
  onEdit,
  onDelete,
  onRetry,
  onDiscard,
}: MessageFocusOverlayProps) {
  const theme = useTheme();
  const c = theme.colors;
  const scale = useRef(new Animated.Value(0.9)).current;
  const opacity = useRef(new Animated.Value(0)).current;
  const deleted = item?.deletedAt !== null;
  const ownReactionCount = item?.reactions.filter((reaction) => reaction.user_id === userId).length ?? 0;
  const hasText = Boolean(item?.content.trim());
  const failed = item?.pending?.status === 'failed';

  useEffect(() => {
    if (!visible) return;
    scale.setValue(theme.reduceMotion ? 1 : 0.9);
    opacity.setValue(0);
    Animated.parallel([
      Animated.timing(scale, { toValue: 1, duration: theme.duration('modal', true), useNativeDriver: true }),
      Animated.timing(opacity, { toValue: 1, duration: theme.duration('modal', true), useNativeDriver: true }),
    ]).start();
  }, [opacity, scale, theme, visible]);

  if (!item) return null;

  const canEditOrDelete = own && !deleted && !item.pending && online;
  const reactionDisabled = deleted || !online || Boolean(item?.pending);
  const reactionLimitReached = ownReactionCount >= config.reactions.maxActivePerMessage;
  const disabledReason = !online ? strings.common.noConnection : undefined;

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      statusBarTranslucent
      onRequestClose={onClose}
      accessibilityViewIsModal
    >
      <Pressable style={[StyleSheet.absoluteFill, { backgroundColor: c.scrim }]} onPress={onClose} accessibilityLabel="Close message actions" />
      <View style={styles.centerer} pointerEvents="box-none">
        <Animated.View
          style={[
            styles.card,
            {
              backgroundColor: c.bg.elevated,
              borderRadius: theme.radius.xl,
              elevation: theme.elevation[2].android,
              opacity,
              transform: [{ scale }],
            },
          ]}
          accessibilityRole="menu"
          accessibilityLabel="Message actions"
        >
          <Text style={[textStyle(theme.typeTokens.bodyMd), styles.preview, { color: c.text.primary }]} numberOfLines={3}>
            {deleted ? strings.chat.deletedMessage : item.content || strings.chat.attachmentOnly}
          </Text>
          <View style={[styles.palette, { borderBottomColor: c.separator }]}>
            {config.reactions.palette.map((emoji) => {
              const selected = item.reactions.some((reaction) => reaction.user_id === userId && reaction.emoji === emoji);
              const disabled = reactionDisabled || (!selected && reactionLimitReached);
              return (
                <Pressable
                  key={emoji}
                  onPress={() => onReact(emoji)}
                  disabled={disabled}
                  accessibilityRole="button"
                  accessibilityLabel={selected ? `${emoji}, remove reaction` : `${emoji}, add reaction`}
                  accessibilityState={{ disabled, selected }}
                  style={({ pressed }) => [styles.emojiButton, { backgroundColor: selected ? c.bg.pressed : pressed && !disabled ? c.bg.pressed : 'transparent', opacity: disabled ? 0.4 : 1 }]}
                >
                  <Text style={styles.emoji}>{emoji}</Text>
                </Pressable>
              );
            })}
          </View>
          {!online ? <Text style={[textStyle(theme.typeTokens.bodySm), styles.paletteReason, { color: c.text.secondary }]}>{strings.common.noConnection}</Text> : reactionLimitReached ? <Text style={[textStyle(theme.typeTokens.bodySm), styles.paletteReason, { color: c.text.secondary }]}>{strings.chat.reactionLimit}</Text> : null}
          <ActionRow label={strings.chat.reply} iconName="action.reply" onPress={onReply} />
          {hasText ? <ActionRow label={strings.chat.forward} iconName="action.forward" onPress={onForward} /> : null}
          <ActionRow label={strings.chat.copy} iconName="action.copy" onPress={onCopy} />
          {own ? <ActionRow label={strings.chat.edit} iconName="action.edit" disabled={!canEditOrDelete} reason={disabledReason} onPress={onEdit} /> : null}
          {own && !failed ? <ActionRow label={strings.chat.delete} iconName="action.delete" destructive disabled={!canEditOrDelete} reason={disabledReason} onPress={onDelete} /> : null}
          {failed ? <ActionRow label={strings.chat.retry} iconName="action.retry" onPress={onRetry} /> : null}
          {failed ? <ActionRow label={strings.chat.discard} iconName="action.discard" destructive disabled={discardDisabled} reason={discardDisabled ? strings.common.noConnection : undefined} onPress={onDiscard} /> : null}
        </Animated.View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  centerer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 24 },
  card: { width: 300, maxWidth: '100%', paddingVertical: 8 },
  preview: { paddingHorizontal: 16, paddingVertical: 12 },
  palette: { flexDirection: 'row', justifyContent: 'space-around', borderBottomWidth: 1, paddingHorizontal: 4, paddingBottom: 4 },
  paletteReason: { paddingHorizontal: 16, paddingTop: 4 },
  emojiButton: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  emoji: { fontSize: 26 },
  actionRow: { minHeight: 48, paddingHorizontal: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  actionCopy: { flex: 1, gap: 1 },
});
