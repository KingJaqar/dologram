/**
 * AND-04: Archive (F9, D-94).
 *
 * Archived chats in the same D-94 order as AND-03. A new message never moves a chat out of the
 * Archive (D-94); Unarchive is one of the row actions of F9 and arrives with Phase 14 (M4-01).
 */
import React, { useCallback } from 'react';
import { FlatList, StyleSheet, View } from 'react-native';
import { useRouter } from 'expo-router';
import { strings } from '@dologram/shared';
import { TopBar } from '../../src/components/TopBar';
import { ChatRow, ChatRowSkeleton } from '../../src/components/ChatRow';
import { EmptyState, ErrorState } from '../../src/components/EmptyState';
import { useChatList } from '../../src/chatList/useChatList';
import { useTheme } from '../../src/theme/ThemeProvider';

const SKELETON_ROWS = 8;

export default function ArchiveScreen() {
  const theme = useTheme();
  const c = theme.colors;
  const router = useRouter();
  const { archived, loading, error, reload } = useChatList();

  const openChat = useCallback(
    (chatId: string) => router.push({ pathname: '/chat/[chatId]', params: { chatId } }),
    [router],
  );

  return (
    <View style={[styles.screen, { backgroundColor: c.bg.app }]}>
      <TopBar title={strings.chatList.archived} onBack={() => router.back()} />

      {loading ? (
        <View accessible accessibilityLabel="Loading">
          {Array.from({ length: SKELETON_ROWS }, (_, index) => (
            <ChatRowSkeleton key={index} />
          ))}
        </View>
      ) : error && archived.length === 0 ? (
        <ErrorState onRetry={() => void reload()} />
      ) : (
        <FlatList
          data={archived}
          keyExtractor={(item) => item.chatId}
          renderItem={({ item }) => <ChatRow item={item} onPress={openChat} />}
          ListEmptyComponent={
            <EmptyState
              iconName="action.archive"
              title={strings.chatList.noArchived}
              message={strings.chatList.noArchivedBody}
            />
          }
          contentContainerStyle={archived.length === 0 ? styles.emptyContent : undefined}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  emptyContent: { flexGrow: 1 },
});
