/**
 * CMP-09: chat list row (AND-03, AND-04) and its loading skeleton (CMP-18).
 *
 * Height 72, a 56 avatar, then the name with the mute icon and the preview with the status icon,
 * the " · " separator and the time. Unread rows use the bold name and primary-coloured preview
 * with the unread badge at the right (12.4, D-92, D-94).
 */
import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import type { ChatListItem } from '@dologram/shared';
import { strings } from '@dologram/shared';
import { useTheme } from '../theme/ThemeProvider';
import { textStyle } from '../theme/typography';
import { Avatar } from './Avatar';
import { Badge } from './Badge';
import { Icon } from './Icon';
import { Skeleton } from './Skeleton';

export interface ChatRowProps {
  item: ChatListItem;
  onPress: (chatId: string) => void;
}

export function ChatRow({ item, onPress }: ChatRowProps) {
  const theme = useTheme();
  const c = theme.colors;
  const unread = item.unreadCount > 0;

  const nameStyle = textStyle(
    unread ? { ...theme.typeTokens.titleSm, weight: 700 } : theme.typeTokens.titleSm,
  );
  const previewStyle = textStyle(
    unread ? { ...theme.typeTokens.bodyMd, weight: 600 } : theme.typeTokens.bodyMd,
  );
  const previewColor = unread ? c.text.primary : c.text.secondary;

  return (
    <Pressable
      style={({ pressed }) => [
        styles.row,
        { backgroundColor: pressed ? c.bg.pressed : c.bg.app },
      ]}
      onPress={() => onPress(item.chatId)}
      accessibilityRole="button"
      accessibilityLabel={item.accessibilityLabel}
    >
      <Avatar
        id={item.avatarId}
        displayName={item.avatarName}
        size={56}
        isSavedMessages={item.savedMessages}
      />

      <View style={styles.body}>
        <View style={styles.nameLine}>
          <Text style={[nameStyle, { color: c.text.primary }]} numberOfLines={1}>
            {item.title}
          </Text>
          {item.muted ? (
            <Icon name="action.mute" size="sm" color={c.text.secondary} />
          ) : null}
        </View>

        <View style={styles.previewLine}>
          {item.ownStatus !== null ? (
            <Icon
              name={item.ownStatus === 'seen' ? 'status.seen' : 'status.sent'}
              size="sm"
              color={c.text.secondary}
            />
          ) : null}
          <Text
            style={[previewStyle, styles.preview, { color: previewColor }]}
            numberOfLines={1}
          >
            {item.preview}
          </Text>
          {item.timeLabel.length > 0 ? (
            <Text style={[previewStyle, { color: previewColor }]} numberOfLines={1}>
              {` · ${item.timeLabel}`}
            </Text>
          ) : null}
        </View>
      </View>

      {unread ? <Badge count={item.unreadCount} muted={item.muted} /> : null}
    </Pressable>
  );
}

// ─── Archived (n) row (AND-03, CMP-09) ────────────────────────────────────────

export interface ArchivedRowProps {
  count: number;
  onPress: () => void;
}

export function ArchivedRow({ count, onPress }: ArchivedRowProps) {
  const theme = useTheme();
  const c = theme.colors;
  const label = strings.chatList.archivedRow(count);

  return (
    <Pressable
      style={({ pressed }) => [
        styles.row,
        { backgroundColor: pressed ? c.bg.pressed : c.bg.app },
      ]}
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={label}
    >
      <View style={[styles.archiveCircle, { backgroundColor: c.bg.surface }]}>
        <Icon name="action.archive" size="lg" color={c.text.primary} />
      </View>
      <View style={styles.body}>
        <Text
          style={[textStyle(theme.typeTokens.titleSm), { color: c.text.primary }]}
          numberOfLines={1}
        >
          {label}
        </Text>
      </View>
    </Pressable>
  );
}

// ─── Skeleton (CMP-18 chat list: 8 rows) ──────────────────────────────────────

export function ChatRowSkeleton() {
  return (
    <View style={styles.row}>
      <Skeleton width={56} height={56} borderRadius={28} />
      <View style={[styles.body, styles.skeletonBody]}>
        <Skeleton width="40%" height={14} />
        <Skeleton width="70%" height={12} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    height: 72,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
    gap: 12,
  },
  body: {
    flex: 1,
    justifyContent: 'center',
    gap: 2,
  },
  nameLine: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  previewLine: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  preview: {
    flexShrink: 1,
  },
  archiveCircle: {
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
  },
  skeletonBody: {
    gap: 8,
  },
});
