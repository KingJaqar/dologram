/**
 * CMP-14: folder tabs (AND-03, AND-13).
 *
 * A horizontally scrolling row under the chat list top bar: "All", then the user's folders in
 * creation order, then a Folders button. The row is shown even when the user has no folders.
 * Folders themselves are F9 (Phase 14, M4-01), so the chat list passes an empty list until then.
 */
import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { strings } from '@dologram/shared';
import { useTheme } from '../theme/ThemeProvider';
import { textStyle } from '../theme/typography';
import { IconButton } from './Button';

export interface FolderTabsFolder {
  folder_id: string;
  name: string;
}

export interface FolderTabsProps {
  folders: readonly FolderTabsFolder[];
  /** Selected folder id; null is "All". */
  activeId: string | null;
  onSelect: (folderId: string | null) => void;
  onOpenFolders: () => void;
}

export function FolderTabs({ folders, activeId, onSelect, onOpenFolders }: FolderTabsProps) {
  const theme = useTheme();
  const c = theme.colors;

  return (
    <View
      style={[styles.bar, { borderBottomColor: c.separator }]}
      accessibilityRole="tablist"
    >
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.row}>
        <FolderTab
          label={strings.chatList.all}
          active={activeId === null}
          onPress={() => onSelect(null)}
        />
        {folders.map((folder) => (
          <FolderTab
            key={folder.folder_id}
            label={folder.name}
            active={activeId === folder.folder_id}
            onPress={() => onSelect(folder.folder_id)}
          />
        ))}
        <IconButton
          iconName="action.folder"
          iconSize="md"
          accessibilityLabel={strings.chatList.folders}
          onPress={onOpenFolders}
        />
      </ScrollView>
    </View>
  );
}

function FolderTab({
  label,
  active,
  onPress,
}: {
  label: string;
  active: boolean;
  onPress: () => void;
}) {
  const theme = useTheme();
  const c = theme.colors;

  return (
    <Pressable
      style={({ pressed }) => [
        styles.tab,
        pressed ? { backgroundColor: c.bg.pressed } : null,
      ]}
      onPress={onPress}
      accessibilityRole="tab"
      accessibilityLabel={label}
      accessibilityState={{ selected: active }}
    >
      <Text
        style={[
          textStyle(theme.typeTokens.labelMd),
          styles.tabLabel,
          { color: active ? c.text.primary : c.text.secondary },
        ]}
        numberOfLines={1}
        maxFontSizeMultiplier={1.5}
      >
        {label}
      </Text>
      {active ? (
        <View style={[styles.indicator, { backgroundColor: c.brand.primary }]} />
      ) : null}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  bar: {
    height: 44,
    justifyContent: 'center',
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  row: {
    alignItems: 'center',
  },
  tab: {
    height: 44,
    justifyContent: 'center',
    paddingHorizontal: 16,
    maxWidth: 160,
  },
  tabLabel: {
    maxWidth: 128,
  },
  indicator: {
    position: 'absolute',
    left: 16,
    right: 16,
    bottom: 0,
    height: 2,
    borderTopLeftRadius: 2,
    borderTopRightRadius: 2,
  },
});
