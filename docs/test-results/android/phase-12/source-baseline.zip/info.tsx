/**
 * AND-12: Chat info (M2-07, D-58, D-70, D-91, D-109).
 *
 * A direct chat shows the other member's display name, username and initials and no member list,
 * because D-70 fixes the two rows of a direct chat and they cannot be removed. A group shows its
 * title, "<n> members", and every member with its role; the owner adds and removes members and any
 * member may leave, with ownership passing on the server (D-91).
 *
 * Mute and Archive are the F9 controls (D-24) and arrive with Phase 14, so this screen does not
 * render them yet. Every change needs a connection and is disabled offline with "No connection"
 * (12.5).
 */
import React, { useCallback, useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import {
  insertMember,
  maxSelectableMembers,
  removeMember,
  strings,
  toggleContactSelection,
  type ChatInfoMember,
} from '@dologram/shared';
import { TopBar } from '../../../src/components/TopBar';
import { Avatar } from '../../../src/components/Avatar';
import { Button } from '../../../src/components/Button';
import { ContactRow } from '../../../src/components/ContactRow';
import { Dialog } from '../../../src/components/Dialog';
import { EmptyState, ErrorState } from '../../../src/components/EmptyState';
import { MemberRow } from '../../../src/components/MemberRow';
import { SkeletonRow } from '../../../src/components/Skeleton';
import { BottomSheet } from '../../../src/components/BottomSheet';
import { Icon } from '../../../src/components/Icon';
import { useToast } from '../../../src/components/Toast';
import { useTheme } from '../../../src/theme/ThemeProvider';
import { textStyle } from '../../../src/theme/typography';
import { useAuth } from '../../../src/auth/AuthProvider';
import { useNetState } from '../../../src/net/netState';
import { supabase } from '../../../src/lib/supabase';
import { getLocalDatabase } from '../../../src/queue/db';
import { useChatInfo } from '../../../src/chats/useChatInfo';
import { useContacts } from '../../../src/chats/useContacts';
import { mutationErrorMessage } from '../../../src/chats/errors';
import { deleteCachedChat } from '../../../src/sync/localCache';
import { notifyCacheChange } from '../../../src/sync/cacheEvents';
import { resyncNow } from '../../../src/sync/lifecycle';

const SKELETON_ROWS = 4;

type ActionButtonProps = {
  iconName: string;
  label: string;
  disabled: boolean;
  onPress: () => void;
};

function ActionButton({ iconName, label, disabled, onPress }: ActionButtonProps) {
  const theme = useTheme();
  const c = theme.colors;
  return (
    <Pressable
      style={({ pressed }) => [
        styles.action,
        {
          backgroundColor: pressed && !disabled ? c.bg.pressed : 'transparent',
          borderRadius: theme.radius.md,
          opacity: disabled ? 0.5 : 1,
        },
      ]}
      onPress={onPress}
      disabled={disabled}
      accessibilityRole="button"
      accessibilityLabel={label}
      accessibilityState={{ disabled }}
    >
      <Icon name={iconName} size="md" color={disabled ? c.text.muted : c.text.primary} />
      <Text style={[textStyle(theme.typeTokens.labelMd), { color: c.text.primary }]}>{label}</Text>
    </Pressable>
  );
}

export default function ChatInfoScreen() {
  const { chatId } = useLocalSearchParams<{ chatId: string }>();
  const theme = useTheme();
  const c = theme.colors;
  const router = useRouter();
  const net = useNetState();
  const { session } = useAuth();
  const { showToast } = useToast();
  const userId = session?.user.id ?? null;

  const { loading, error, info, reload, refresh } = useChatInfo(chatId);
  const memberIds = useMemo(() => info?.members.map((member) => member.userId) ?? [], [info]);
  const { contacts } = useContacts(memberIds);

  const [addVisible, setAddVisible] = useState(false);
  const [addSelected, setAddSelected] = useState<readonly string[]>([]);
  const [adding, setAdding] = useState(false);
  const [removeTarget, setRemoveTarget] = useState<ChatInfoMember | null>(null);
  const [removing, setRemoving] = useState(false);
  const [leaveVisible, setLeaveVisible] = useState(false);
  const [leaving, setLeaving] = useState(false);

  const offline = !net.isConnected;

  const openAddMembers = useCallback(() => {
    setAddSelected([]);
    setAddVisible(true);
  }, []);

  const onToggleAdd = useCallback((memberId: string) => {
    setAddSelected((current) => toggleContactSelection(current, memberId, maxSelectableMembers));
  }, []);

  const refreshAfterChange = useCallback(async () => {
    await resyncNow();
    await reload();
  }, [reload]);

  const onAddMembers = useCallback(async () => {
    if (!chatId || addSelected.length === 0 || adding || offline) return;
    setAdding(true);
    let failed = 0;
    try {
      for (const memberId of addSelected) {
        const inserted = await insertMember(supabase, {
          chat_id: chatId,
          user_id: memberId,
          role: 'member',
        });
        if (inserted.error) failed += 1;
      }
      setAddVisible(false);
      setAddSelected([]);
      if (failed > 0) showToast({ message: strings.newGroup.membersFailed(failed) });
      await refreshAfterChange();
    } catch {
      showToast({ message: strings.chatInfo.addFailed });
    } finally {
      setAdding(false);
    }
  }, [chatId, addSelected, adding, offline, showToast, refreshAfterChange]);

  const onRemove = useCallback(async () => {
    if (!chatId || removeTarget === null || removing) return;
    setRemoving(true);
    try {
      const removed = await removeMember(supabase, chatId, removeTarget.userId);
      if (removed.error) {
        showToast({
          message: mutationErrorMessage(removed.error, strings.chatInfo.removeFailed),
        });
        return;
      }
      setRemoveTarget(null);
      await refreshAfterChange();
    } catch {
      showToast({ message: strings.chatInfo.removeFailed });
    } finally {
      setRemoving(false);
    }
  }, [chatId, removeTarget, removing, showToast, refreshAfterChange]);

  const onLeave = useCallback(async () => {
    if (!chatId || !userId || leaving) return;
    setLeaving(true);
    try {
      const removed = await removeMember(supabase, chatId, userId);
      if (removed.error) {
        showToast({ message: mutationErrorMessage(removed.error, strings.chatInfo.leaveFailed) });
        return;
      }
      const db = await getLocalDatabase();
      await deleteCachedChat(db, chatId);
      notifyCacheChange();
      setLeaveVisible(false);
      router.replace('/(main)/(tabs)');
    } catch {
      showToast({ message: strings.chatInfo.leaveFailed });
    } finally {
      setLeaving(false);
    }
  }, [chatId, userId, leaving, showToast, router]);

  return (
    <View style={[styles.screen, { backgroundColor: c.bg.app }]}>
      <TopBar title={strings.chatInfo.title} onBack={() => router.back()} />

      {loading ? (
        <View accessible accessibilityLabel="Loading">
          {Array.from({ length: SKELETON_ROWS }, (_, index) => (
            <SkeletonRow key={index} />
          ))}
        </View>
      ) : info === null ? (
        <ErrorState
          title={strings.chatInfo.unavailable}
          message={error ? strings.common.checkConnection : strings.chatInfo.unavailableBody}
          onRetry={() => void refresh()}
        />
      ) : (
        <ScrollView contentContainerStyle={styles.content}>
          <View style={[styles.header, { padding: theme.space[6], gap: theme.space[6] }]}>
            <Avatar
              id={info.avatarId}
              displayName={info.avatarName}
              size={96}
              isSavedMessages={info.savedMessages}
            />
            <View style={{ alignItems: 'center', gap: 4 }}>
              <Text
                style={[
                  textStyle(theme.typeTokens.titleLg),
                  { color: c.text.primary, textAlign: 'center' },
                ]}
                numberOfLines={2}
              >
                {info.title}
              </Text>
              {info.subtitle.length > 0 ? (
                <Text
                  style={[
                    textStyle(theme.typeTokens.bodyMd),
                    { color: c.text.secondary, textAlign: 'center' },
                  ]}
                  numberOfLines={1}
                >
                  {info.subtitle}
                </Text>
              ) : null}
            </View>
          </View>

          {offline ? (
            <Text
              style={[
                textStyle(theme.typeTokens.bodySm),
                { color: c.text.secondary, paddingHorizontal: theme.space[4] },
              ]}
            >
              {strings.chatInfo.offline}
            </Text>
          ) : null}

          {info.canLeave ? (
            <View style={[styles.actionRow, { paddingVertical: theme.space[3] }]}>
              <ActionButton
                iconName="action.signOut"
                label={strings.chatInfo.leave}
                disabled={offline || leaving}
                onPress={() => setLeaveVisible(true)}
              />
            </View>
          ) : null}

          {info.isGroup ? (
            <View style={{ paddingBottom: theme.space[6] }}>
              <View
                style={[
                  styles.sectionHeader,
                  { paddingHorizontal: theme.space[4], paddingBottom: theme.space[2] },
                ]}
              >
                <Text style={[textStyle(theme.typeTokens.titleSm), { color: c.text.primary }]}>
                  {strings.chatInfo.members}
                </Text>
                <Text style={[textStyle(theme.typeTokens.bodySm), { color: c.text.secondary }]}>
                  {strings.chatInfo.membersCount(info.members.length)}
                </Text>
              </View>

              {info.canAddMembers ? (
                <Pressable
                  style={({ pressed }) => [
                    styles.addRow,
                    {
                      paddingHorizontal: theme.space[4],
                      backgroundColor: pressed ? c.bg.pressed : 'transparent',
                    },
                  ]}
                  onPress={openAddMembers}
                  disabled={offline}
                  accessibilityRole="button"
                  accessibilityLabel={strings.chatInfo.addMembers}
                  accessibilityState={{ disabled: offline }}
                >
                  <View
                    style={[
                      styles.addIcon,
                      { backgroundColor: c.bg.surface, borderRadius: 24, opacity: offline ? 0.5 : 1 },
                    ]}
                  >
                    <Icon name="nav.new" size="md" color={c.brand.primary} />
                  </View>
                  <Text style={[textStyle(theme.typeTokens.bodyLg), { color: c.brand.primary }]}>
                    {strings.chatInfo.addMembers}
                  </Text>
                </Pressable>
              ) : null}

              {info.members.map((member) => (
                <MemberRow
                  key={member.userId}
                  member={member}
                  canRemove={info.canManageMembers}
                  disabled={offline || removing}
                  onRemove={setRemoveTarget}
                />
              ))}
            </View>
          ) : null}
        </ScrollView>
      )}

      <BottomSheet visible={addVisible} onClose={() => setAddVisible(false)}>
        <View style={{ paddingBottom: theme.space[6] }}>
          <Text
            style={[
              textStyle(theme.typeTokens.titleMd),
              { color: c.text.primary, paddingHorizontal: theme.space[4], paddingBottom: theme.space[2] },
            ]}
          >
            {strings.chatInfo.addMembers}
          </Text>

          {contacts.length === 0 ? (
            <EmptyState
              iconName="action.newChat"
              title={strings.newGroup.noContacts}
              message={strings.newGroup.noContactsBody}
            />
          ) : (
            <ScrollView style={{ maxHeight: 320 }}>
              {contacts.map((contact) => {
                const isSelected = addSelected.includes(contact.userId);
                return (
                  <ContactRow
                    key={contact.userId}
                    userId={contact.userId}
                    displayName={contact.displayName}
                    selected={isSelected}
                    disabled={!isSelected && addSelected.length >= maxSelectableMembers}
                    onToggle={onToggleAdd}
                  />
                );
              })}
            </ScrollView>
          )}

          <View style={{ paddingHorizontal: theme.space[4], paddingTop: theme.space[3] }}>
            <Button
              label={strings.chatInfo.add}
              onPress={() => void onAddMembers()}
              disabled={offline || addSelected.length === 0 || adding}
              loading={adding}
              fullWidth
            />
          </View>
        </View>
      </BottomSheet>

      <Dialog
        visible={removeTarget !== null}
        title={strings.chatInfo.removeTitle(removeTarget?.displayName ?? '')}
        message={strings.chatInfo.removeBody}
        confirmLabel={strings.chatInfo.remove}
        onConfirm={() => void onRemove()}
        onDismiss={() => setRemoveTarget(null)}
        destructive
      />

      <Dialog
        visible={leaveVisible}
        title={strings.chatInfo.leaveTitle}
        message={strings.chatInfo.leaveBody}
        confirmLabel={strings.chatInfo.leave}
        onConfirm={() => void onLeave()}
        onDismiss={() => setLeaveVisible(false)}
        destructive
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { flexGrow: 1, paddingBottom: 24 },
  header: { alignItems: 'center' },
  actionRow: { flexDirection: 'row', justifyContent: 'center', gap: 8 },
  action: { width: 72, paddingVertical: 8, alignItems: 'center', gap: 4 },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'baseline',
    justifyContent: 'space-between',
  },
  addRow: { height: 64, flexDirection: 'row', alignItems: 'center', gap: 12 },
  addIcon: { width: 48, height: 48, alignItems: 'center', justifyContent: 'center' },
});
