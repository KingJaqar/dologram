/**
 * AND-09: Media viewer screen placeholder.
 * Phase 12 will complete this screen.
 */
import React from 'react';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { View, Text, StyleSheet } from 'react-native';
import { useTheme } from '../../../../src/theme/ThemeProvider';
import { TopBar } from '../../../../src/components/TopBar';

export default function MediaViewerScreen() {
  const { chatId, mediaId } = useLocalSearchParams<{ chatId: string; mediaId: string }>();
  const theme = useTheme();
  const router = useRouter();
  return (
    <View style={[styles.container, { backgroundColor: theme.colors.bg.app }]}>
      <TopBar title="Media" onBack={() => router.back()} />
      <View style={styles.body}>
        <Text style={[styles.text, { color: theme.colors.text.secondary }]}>
          {`chatId: ${chatId} mediaId: ${mediaId} — Phase 12`}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  body: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  text: { fontSize: 14 },
});
