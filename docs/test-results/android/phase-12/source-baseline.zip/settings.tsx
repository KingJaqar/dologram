/**
 * Settings placeholder — AND-14.
 * Phase 4 adds the Account rows Change password (AND-02) and Sign out (D-51).
 * Phase 5 adds the unsent-items warning and the local-data wipe; Phase 15 completes the screen.
 */
import React from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { strings } from '@dologram/shared';
import { useTheme } from '../../../src/theme/ThemeProvider';
import { textStyle } from '../../../src/theme/typography';
import { useNetState } from '../../../src/net/netState';
import { supabase } from '../../../src/lib/supabase';
import { TopBar } from '../../../src/components/TopBar';
import { useToast } from '../../../src/components/Toast';

interface SettingsRowProps {
  label: string;
  onPress: () => void;
  disabled?: boolean;
  helper?: string;
  danger?: boolean;
}

const ROW_HEIGHT = 56;

function SettingsRow({ label, onPress, disabled = false, helper, danger = false }: SettingsRowProps) {
  const theme = useTheme();
  const labelColor = danger ? theme.colors.error.text : theme.colors.text.primary;

  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      accessibilityRole="button"
      accessibilityLabel={label}
      accessibilityState={{ disabled }}
      style={({ pressed }) => ({
        minHeight: ROW_HEIGHT,
        justifyContent: 'center',
        paddingHorizontal: theme.space[4],
        backgroundColor: pressed && !disabled ? theme.colors.bg.pressed : 'transparent',
        opacity: disabled ? 0.5 : 1,
      })}
    >
      <Text style={[textStyle(theme.typeTokens.bodyLg), { color: labelColor }]}>{label}</Text>
      {helper ? (
        <Text style={[textStyle(theme.typeTokens.bodySm), { color: theme.colors.text.secondary }]}>
          {helper}
        </Text>
      ) : null}
    </Pressable>
  );
}

export default function SettingsScreen() {
  const theme = useTheme();
  const router = useRouter();
  const net = useNetState();
  const { showToast } = useToast();

  const offline = !net.isConnected;

  async function handleSignOut() {
    const { error } = await supabase.auth.signOut();
    if (error) {
      showToast({ message: strings.common.checkConnection });
    }
  }

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.bg.app }}>
      <TopBar title={strings.settings.title} />

      <ScrollView>
        <Text
          style={[
            textStyle(theme.typeTokens.labelMd),
            {
              color: theme.colors.text.secondary,
              paddingHorizontal: theme.space[4],
              paddingTop: theme.space[5],
              paddingBottom: theme.space[2],
            },
          ]}
          accessibilityRole="header"
        >
          {strings.settings.account}
        </Text>

        <SettingsRow
          label={strings.settings.changePassword}
          onPress={() => router.push('/change-password')}
          disabled={offline}
          helper={offline ? strings.common.noConnection : undefined}
        />

        <SettingsRow
          label={strings.settings.signOut}
          danger
          onPress={() => {
            void handleSignOut();
          }}
        />
      </ScrollView>
    </View>
  );
}
