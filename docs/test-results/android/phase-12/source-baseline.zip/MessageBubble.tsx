/** CMP-07, CMP-08 and CMP-12: message bubble, reply quote and reactions. */
import React, { useEffect, useMemo, useRef } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { strings } from '@dologram/shared';
import { useTheme } from '../theme/ThemeProvider';
import { textStyle } from '../theme/typography';
import { Icon } from './Icon';
import { MessageText } from './MessageText';
import type { ChatMessageItem } from '../chat/query';

export type BubbleStatus = 'sent' | 'seen' | null;

export type ReplyPreview = { senderName: string; content: string; deleted: boolean };

export type MessageBubbleProps = {
  item: ChatMessageItem;
  own: boolean;
  userId: string;
  status: BubbleStatus;
  showTime: boolean;
  onPress: () => void;
  onLongPress?: () => void;
  onDoubleTap?: () => void;
  onReactionPress?: (emoji: string) => void;
  reactionDisabled?: boolean;
  replyPreview?: ReplyPreview;
  onRetry?: () => void;
  onDiscard?: () => void;
  discardDisabled?: boolean;
};

function formatTime(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}

function statusLabel(item: ChatMessageItem, status: BubbleStatus): string | null {
  if (item.pending?.status === 'queued') return strings.chat.statusQueued;
  if (item.pending?.status === 'sending') return strings.chat.statusSending;
  if (item.pending?.status === 'failed') return strings.chat.statusFailed;
  if (status === 'seen') return strings.chat.statusSeen;
  if (status === 'sent') return strings.chat.statusSent;
  return null;
}

function groupReactions(item: ChatMessageItem, userId: string): { emoji: string; count: number; own: boolean }[] {
  const grouped = new Map<string, { count: number; own: boolean }>();
  for (const reaction of item.reactions) {
    const current = grouped.get(reaction.emoji) ?? { count: 0, own: false };
    grouped.set(reaction.emoji, { count: current.count + 1, own: current.own || reaction.user_id === userId });
  }
  return [...grouped.entries()].map(([emoji, value]) => ({ emoji, ...value }));
}

export function MessageBubble({
  item,
  own,
  userId,
  status,
  showTime,
  onPress,
  onLongPress,
  onDoubleTap,
  onReactionPress,
  reactionDisabled = false,
  replyPreview,
  onRetry,
  onDiscard,
  discardDisabled = false,
}: MessageBubbleProps) {
  const theme = useTheme();
  const c = theme.colors;
  const tapTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const deleted = item.deletedAt !== null;
  const label = statusLabel(item, status);
  const statusColor = item.pending?.status === 'failed' ? c.error.text : c.text.muted;
  const contentColor = own ? c.bubble.outgoingText : c.bubble.incomingText;
  const reactions = useMemo(() => groupReactions(item, userId), [item, userId]);

  useEffect(() => () => { if (tapTimer.current) clearTimeout(tapTimer.current); }, []);

  const handlePress = () => {
    if (!onDoubleTap) { onPress(); return; }
    if (tapTimer.current) {
      clearTimeout(tapTimer.current);
      tapTimer.current = null;
      onDoubleTap();
      return;
    }
    tapTimer.current = setTimeout(() => { tapTimer.current = null; onPress(); }, 220);
  };

  return (
    <View style={[styles.row, own ? styles.ownRow : styles.receivedRow]}>
      <Pressable
        onPress={handlePress}
        onLongPress={onLongPress}
        delayLongPress={400}
        style={({ pressed }) => [styles.bubble, { backgroundColor: own ? c.bubble.outgoing : c.bubble.incoming, borderRadius: theme.radius.bubble, opacity: pressed ? 0.86 : 1, maxWidth: '78%' }]}
        accessibilityRole="button"
        accessibilityLabel={`${own ? 'You' : item.senderName}, ${deleted ? strings.chat.deletedMessage : item.content}${item.editedAt ? `, ${strings.chat.edited}` : ''}${label ? `, ${label}` : ', sent'}`}
      >
        {!own && item.senderName ? <Text style={[textStyle(theme.typeTokens.labelMd), { color: c.text.secondary }]}>{item.senderName}</Text> : null}
        {replyPreview ? (
          <View style={[styles.replyQuote, { borderLeftColor: own ? c.bubble.outgoingText : c.brand.primary, backgroundColor: own ? c.bubble.join : c.bg.surface }]}>
            <Text style={[textStyle(theme.typeTokens.labelMd), { color: contentColor }]} numberOfLines={1}>{replyPreview.senderName}</Text>
            <Text style={[textStyle(theme.typeTokens.bodySm), { color: contentColor }]} numberOfLines={1}>{replyPreview.deleted ? strings.chat.deletedMessage : replyPreview.content}</Text>
          </View>
        ) : null}
        {deleted ? (
          <View style={styles.deletedRow}><Icon name="chat.deleted" size="xs" color={contentColor} accessibilityLabel="" /><Text style={[textStyle(theme.typeTokens.bodyMd), styles.deleted, { color: contentColor }]}>{strings.chat.deletedMessage}</Text></View>
        ) : item.content ? <MessageText content={item.content} color={contentColor} /> : null}
        {item.attachmentCount > 0 ? <View style={[styles.attachment, { backgroundColor: own ? c.bubble.join : c.bg.surface }]}><Icon name="action.file" size="md" color={contentColor} accessibilityLabel="" /><Text style={[textStyle(theme.typeTokens.bodySm), { color: contentColor }]}>Waiting for upload</Text></View> : null}
        {item.editedAt && !deleted ? <Text style={[textStyle(theme.typeTokens.bodySm), { color: c.text.muted }]}>{strings.chat.edited}</Text> : null}
        {reactions.length > 0 ? (
          <View style={styles.reactions}>
            {reactions.map((reaction) => (
              <Pressable key={reaction.emoji} onPress={() => onReactionPress?.(reaction.emoji)} disabled={reactionDisabled || !onReactionPress} accessibilityRole="button" accessibilityLabel={`${reaction.emoji}, ${reaction.count} reactions${reaction.own ? ', you reacted' : ''}`} accessibilityState={{ disabled: reactionDisabled || !onReactionPress, selected: reaction.own }} style={({ pressed }) => [styles.reaction, { backgroundColor: reaction.own ? c.bg.pressed : c.bg.surface, borderColor: reaction.own ? c.brand.primary : c.separator, opacity: reactionDisabled ? 0.5 : pressed ? 0.75 : 1 }]}>
                <Text style={{ color: c.text.primary }}>{reaction.emoji}</Text><Text style={[textStyle(theme.typeTokens.labelMd), { color: reaction.own ? c.brand.primary : c.text.primary }]}>{reaction.count}</Text>
              </Pressable>
            ))}
          </View>
        ) : null}
        {showTime ? <Text style={[textStyle(theme.typeTokens.bodySm), { color: c.text.muted }]}>{formatTime(item.createdAt)}</Text> : null}
      </Pressable>
      {own && label ? <View style={styles.statusRow}><Icon name={item.pending?.status === 'failed' ? 'status.failed' : status === 'seen' ? 'status.seen' : item.pending?.status === 'sending' ? 'status.sending' : item.pending?.status === 'queued' ? 'status.queued' : 'status.sent'} size="xs" color={statusColor} accessibilityLabel="" /><Text style={[textStyle(theme.typeTokens.labelMd), { color: statusColor }]}>{label}</Text></View> : null}
      {own && item.pending?.status === 'failed' ? <View style={styles.retryRow}><Pressable onPress={onRetry} accessibilityRole="button" accessibilityLabel="Retry"><Text style={[textStyle(theme.typeTokens.labelMd), { color: c.brand.primary }]}>Retry</Text></Pressable><Pressable onPress={onDiscard} disabled={discardDisabled} accessibilityRole="button" accessibilityLabel="Discard" accessibilityState={{ disabled: discardDisabled }}><Text style={[textStyle(theme.typeTokens.labelMd), { color: c.error.text, opacity: discardDisabled ? 0.5 : 1 }]}>Discard</Text></Pressable></View> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  row: { width: '100%', paddingHorizontal: 12, marginVertical: 3 },
  ownRow: { alignItems: 'flex-end' },
  receivedRow: { alignItems: 'flex-start' },
  bubble: { paddingHorizontal: 12, paddingVertical: 8 },
  deleted: { fontStyle: 'italic' },
  deletedRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  replyQuote: { borderLeftWidth: 3, paddingLeft: 8, paddingVertical: 4, marginBottom: 6, borderRadius: 4 },
  attachment: { flexDirection: 'row', alignItems: 'center', gap: 8, padding: 8, marginTop: 6, borderRadius: 8 },
  reactions: { flexDirection: 'row', flexWrap: 'wrap', gap: 4, marginTop: 4 },
  reaction: { minHeight: 28, paddingHorizontal: 8, borderRadius: 14, borderWidth: 1, flexDirection: 'row', alignItems: 'center', gap: 4 },
  statusRow: { flexDirection: 'row', alignItems: 'center', gap: 3, marginTop: 2, marginRight: 4 },
  retryRow: { flexDirection: 'row', gap: 16, marginTop: 2, marginRight: 4 },
});
