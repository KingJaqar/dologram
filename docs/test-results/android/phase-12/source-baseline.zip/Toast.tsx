/**
 * CMP-17: Toast notification system.
 * One toast at a time, auto-dismiss, live region for screen readers.
 * 12.5, D-95
 */
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from 'react';
import { Animated, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useTheme } from '../theme/ThemeProvider';
import { textStyle } from '../theme/typography';

// ─── Types ────────────────────────────────────────────────────────────────────

export interface ToastOptions {
  message: string;
  /** If set, shows an action button. */
  actionLabel?: string;
  onAction?: () => void;
  /** Override default duration. */
  durationMs?: number;
}

interface ToastContextValue {
  showToast: (options: ToastOptions) => void;
  hideToast: () => void;
}

// ─── Context ──────────────────────────────────────────────────────────────────

const ToastContext = createContext<ToastContextValue>({
  showToast: () => {},
  hideToast: () => {},
});

export function useToast() {
  return useContext(ToastContext);
}

// ─── Provider ────────────────────────────────────────────────────────────────

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const theme = useTheme();
  const insets = useSafeAreaInsets();
  const c = theme.colors;

  const [current, setCurrent] = useState<ToastOptions | null>(null);
  const opacityRef = useRef<Animated.Value | null>(null);
  if (opacityRef.current === null) {
    opacityRef.current = new Animated.Value(0);
  }
  const opacity = opacityRef.current;
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const hide = useCallback(() => {
    Animated.timing(opacity, {
      toValue: 0,
      duration: theme.duration('fast', true),
      useNativeDriver: true,
    }).start(() => setCurrent(null));
  }, [opacity, theme]);

  const show = useCallback(
    (options: ToastOptions) => {
      if (timerRef.current) clearTimeout(timerRef.current);

      setCurrent(options);
      opacity.setValue(0);
      Animated.timing(opacity, {
        toValue: 1,
        duration: theme.duration('fast', true),
        useNativeDriver: true,
      }).start();

      const ms = options.durationMs ?? theme.motion.toast.duration;
      timerRef.current = setTimeout(hide, ms);
    },
    [opacity, theme, hide],
  );

  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, []);

  return (
    <ToastContext.Provider value={{ showToast: show, hideToast: hide }}>
      {children}

      {current ? (
        <View
          style={[
            styles.portal,
            { bottom: Math.max(insets.bottom + 8, 16), zIndex: theme.z.toast },
          ]}
          pointerEvents="box-none"
          accessibilityLiveRegion="polite"
          importantForAccessibility="yes"
          accessibilityLabel={current.message}
        >
          <Animated.View
            style={[
              styles.toast,
              {
                backgroundColor: c.text.primary,
                borderRadius: theme.radius.md,
                paddingHorizontal: theme.space[4],
                paddingVertical: theme.space[3],
                opacity,
                maxWidth: 360,
                shadowColor: c.shadow,
              },
            ]}
          >
            <Text
              style={[textStyle(theme.typeTokens.bodyMd), { color: c.text.inverse, flex: 1 }]}
              numberOfLines={2}
            >
              {current.message}
            </Text>
            {current.actionLabel ? (
              <Pressable
                onPress={() => {
                  current.onAction?.();
                  hide();
                }}
                accessibilityRole="button"
                accessibilityLabel={current.actionLabel}
                style={styles.action}
              >
                <Text
                  style={[
                    textStyle(theme.typeTokens.labelLg),
                    { color: c.brand.primary },
                  ]}
                >
                  {current.actionLabel}
                </Text>
              </Pressable>
            ) : null}
          </Animated.View>
        </View>
      ) : null}
    </ToastContext.Provider>
  );
}

const styles = StyleSheet.create({
  portal: {
    position: 'absolute',
    left: 16,
    right: 16,
    alignItems: 'center',
  },
  toast: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    // shadowColor applied inline from theme.colors.shadow
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 4,
  },
  action: { paddingLeft: 8 },
});
