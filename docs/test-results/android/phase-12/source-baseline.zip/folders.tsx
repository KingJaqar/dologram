/**
 * AND-13: Folders screen placeholder.
 * Phase 14 will complete this screen with folder management.
 */
import React from 'react';
import { useRouter } from 'expo-router';
import { View, Text, StyleSheet } from 'react-native';
import { useTheme } from '../src/theme/ThemeProvider';
import { TopBar } from '../src/components/TopBar';

export default function FoldersScreen() {
  const theme = useTheme();
  const router = useRouter();
  return (
    <View style={[styles.container, { backgroundColor: theme.colors.bg.app }]}>
      <TopBar title="Folders" onBack={() => router.back()} />
      <View style={styles.body}>
        <Text style={[styles.text, { color: theme.colors.text.secondary }]}>
          Folder management — Phase 14
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  body: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  text: { fontSize: 14 },
});
