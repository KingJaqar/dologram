/**
 * Root layout — wraps the app in ThemeProvider, SafeAreaProvider, ToastProvider and AuthProvider.
 * Loads Inter and JetBrains Mono fonts and holds the splash screen until fonts and the
 * stored session are ready. Phase 4 Step 3 adds the auth guard (M2-04, D-78).
 */
import React, { useEffect } from 'react';
import { View } from 'react-native';
import { Stack, useRouter, useSegments } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
} from '@expo-google-fonts/inter';
import { JetBrainsMono_400Regular } from '@expo-google-fonts/jetbrains-mono';
import { ThemeProvider, useTheme } from '../src/theme/ThemeProvider';
import { ToastProvider } from '../src/components/Toast';
import { AuthProvider, useAuth } from '../src/auth/AuthProvider';
import { startQueueWorker } from '../src/queue/worker';
import { startSync } from '../src/sync/lifecycle';

// Prevent the splash screen from auto-hiding until fonts and the session are loaded.
SplashScreen.preventAutoHideAsync();

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
    JetBrainsMono_400Regular,
  });

  // Assumption A-07: both font packages work on SDK 57.
  // Fallback: if fontError is set, we continue with system fonts rather than blocking the app.
  const fontsReady = fontsLoaded || Boolean(fontError);

  return (
    <SafeAreaProvider>
      <ThemeProvider>
        <ToastProvider>
          <AuthProvider>
            <RootNavigator fontsReady={fontsReady} />
          </AuthProvider>
        </ToastProvider>
      </ThemeProvider>
    </SafeAreaProvider>
  );
}

function RootNavigator({ fontsReady }: { fontsReady: boolean }) {
  const { status } = useAuth();
  const segments = useSegments();
  const router = useRouter();
  const theme = useTheme();

  // Keep the splash screen up until fonts and the stored session are both known, so a
  // forced password change never flashes the chat list first (D-78).
  useEffect(() => {
    if (fontsReady && status !== 'loading') {
      void SplashScreen.hideAsync();
    }
  }, [fontsReady, status]);

  // LS-3: the delivery worker runs only for a signed-in user and only in the foreground.
  // M2-05: the sync engine follows the same session, subscribes to the published tables and
  // resyncs on every foreground and reconnect.
  useEffect(() => {
    if (status !== 'signedIn') return;
    const worker = startQueueWorker();
    const sync = startSync();
    return () => {
      sync.stop();
      worker.stop();
    };
  }, [status]);

  // M2-04 guard: signed-out → AND-01; must change password → AND-02 only; signed-in → leave
  // the signed-out screens. Sign-up (AND-01b) and the password-reset screens are reachable
  // while signed out (D-163, D-181). `/change-password` and `/reset-password` stay reachable
  // while signed in: Settings opens AND-02 (D-51) and the recovery exchange creates the session
  // before the new password is saved (D-181).
  useEffect(() => {
    if (status === 'loading') return;

    const root = segments[0];
    const signedOutRoute =
      root === 'sign-in' ||
      root === 'sign-up' ||
      root === 'forgot-password' ||
      root === 'reset-password';
    const onChangePassword = root === 'change-password';
    const signedInOnlyRoute =
      root === 'sign-in' || root === 'sign-up' || root === 'forgot-password';

    if (status === 'signedOut') {
      if (!signedOutRoute) router.replace('/sign-in');
      return;
    }

    if (status === 'mustChangePassword') {
      if (!onChangePassword) router.replace('/change-password');
      return;
    }

    if (signedInOnlyRoute) router.replace('/(main)/(tabs)');
  }, [status, segments, router]);

  if (!fontsReady || status === 'loading') {
    return <View style={{ flex: 1, backgroundColor: theme.colors.bg.app }} />;
  }

  return (
    <View style={{ flex: 1 }}>
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="forward" options={{ presentation: 'modal' }} />
      </Stack>
    </View>
  );
}
