/**
 * Main authenticated area layout — Stack with header hidden.
 * headerShown: false because TopBar is rendered by each screen (12.6).
 */
import React from 'react';
import { Stack } from 'expo-router';

export default function MainLayout() {
  return <Stack screenOptions={{ headerShown: false }} />;
}
