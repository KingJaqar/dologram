/**
 * Auth state for the app (M2-04, F1, D-78).
 * - Restores the stored Supabase session on start and follows onAuthStateChange.
 * - `mustChangePassword` comes from `app_metadata.must_change_password`, which only the
 *   server can set (D-78); while it is true the root guard renders AND-02 alone.
 * - The own `profiles` row is read through RLS after a normal sign-in. An RLS read before
 *   the password change returns no row by design (D-78), so the profile is loaded again
 *   when the flag clears.
 */
import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';

export type AuthStatus = 'loading' | 'signedOut' | 'mustChangePassword' | 'signedIn';

export interface AuthProfile {
  user_id: string;
  username: string;
  display_name: string;
}

export interface AuthContextValue {
  status: AuthStatus;
  session: Session | null;
  profile: AuthProfile | null;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

function requiresPasswordChange(session: Session | null): boolean {
  const flag: unknown = session?.user.app_metadata?.['must_change_password'];
  return flag === true;
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [status, setStatus] = useState<AuthStatus>('loading');
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<AuthProfile | null>(null);
  const profileUserIdRef = useRef<string | null>(null);

  useEffect(() => {
    let active = true;

    async function loadProfile(userId: string) {
      if (profileUserIdRef.current === userId) return;
      profileUserIdRef.current = userId;

      const { data, error } = await supabase
        .from('profiles')
        .select('user_id, username, display_name')
        .eq('user_id', userId)
        .maybeSingle();

      if (!active) return;

      if (error) {
        // Denied or offline: retry on the next auth event instead of looping.
        profileUserIdRef.current = null;
        return;
      }

      setProfile(data);
    }

    function applySession(next: Session | null, loadOwnProfile: boolean) {
      if (!active) return;

      setSession(next);

      if (!next) {
        profileUserIdRef.current = null;
        setProfile(null);
        setStatus('signedOut');
        return;
      }

      if (requiresPasswordChange(next)) {
        profileUserIdRef.current = null;
        setProfile(null);
        setStatus('mustChangePassword');
        return;
      }

      setStatus('signedIn');
      if (loadOwnProfile) {
        void loadProfile(next.user.id);
      }
    }

    supabase.auth
      .getSession()
      .then(({ data }) => applySession(data.session, true))
      .catch(() => {
        if (active) setStatus('signedOut');
      });

    const { data: listener } = supabase.auth.onAuthStateChange((event, next) => {
      // supabase-js holds its auth lock while this callback runs, so further client calls are deferred.
      setTimeout(() => {
        applySession(next, event !== 'TOKEN_REFRESHED');
      }, 0);
    });

    return () => {
      active = false;
      listener.subscription.unsubscribe();
    };
  }, []);

  const value: AuthContextValue = { status, session, profile };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

/** Hook to consume the auth context. Must be used inside AuthProvider. */
export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>');
  return ctx;
}
