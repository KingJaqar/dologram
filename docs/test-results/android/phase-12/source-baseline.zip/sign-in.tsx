/**
 * AND-01 Sign-in (12.5 sign-in template, M2-04, F1, D-47, rev. 2026-11-09).
 *
 * Changes from original:
 * - Accepts email OR username in a single identifier field.
 *   Username input is resolved to an email via the find_user RPC before signInWithPassword.
 * - "Save login info" toggle (SwitchRow) persists the last-used identifier to
 *   AsyncStorage key `dg.savedLogin` and pre-fills it on next open.
 */
import React, { useState, useEffect } from 'react';
import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { strings, validateEmail, validateUsername } from '@dologram/shared';
import { useTheme } from '../src/theme/ThemeProvider';
import { textStyle } from '../src/theme/typography';
import { useNetState } from '../src/net/netState';
import { supabase } from '../src/lib/supabase';
import { Button, IconButton } from '../src/components/Button';
import { TextField } from '../src/components/TextField';
import { SwitchRow } from '../src/components/SwitchRow';

/** AsyncStorage key for the saved identifier. */
const SAVED_LOGIN_KEY = 'dg.savedLogin';

/**
 * Detects whether the input is an email, a valid username, or neither.
 * Used to decide sign-in strategy and to validate before submit.
 */
function classifyIdentifier(value: string): 'email' | 'username' | 'invalid' {
  if (validateEmail(value)) return 'email';
  if (validateUsername(value)) return 'username';
  return 'invalid';
}

/**
 * AND-01 defines three failure messages: wrong credentials, rate limit, connection.
 * GoTrue answers a wrong email/password with 400; repeated attempts hit 429.
 */
function signInErrorMessage(error: unknown, identifierType: 'email' | 'username'): string {
  const status =
    typeof error === 'object' && error !== null && 'status' in error
      ? (error as { status?: unknown }).status
      : undefined;

  if (status === 400) {
    return identifierType === 'username'
      ? strings.signIn.wrongCredentialsUsername
      : strings.signIn.wrongCredentials;
  }
  if (status === 429) return strings.signIn.tooManyAttempts;
  return strings.common.checkConnection;
}

export default function SignInScreen() {
  const theme = useTheme();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { height } = useWindowDimensions();
  const net = useNetState();

  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [identifierError, setIdentifierError] = useState<string | null>(null);
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [saveLogin, setSaveLogin] = useState(false);

  const offline = !net.isConnected;

  // Restore saved login info on mount
  useEffect(() => {
    AsyncStorage.getItem(SAVED_LOGIN_KEY)
      .then((saved) => {
        if (saved) {
          setIdentifier(saved);
          setSaveLogin(true);
        }
      })
      .catch(() => {
        // Ignore storage errors — form starts empty
      });
  }, []);

  async function handleSignIn() {
    if (offline || submitting) return;

    const trimmedIdentifier = identifier.trim();
    const kind = classifyIdentifier(trimmedIdentifier);

    const nextIdentifierError =
      trimmedIdentifier.length === 0 || kind === 'invalid'
        ? strings.signIn.invalidIdentifier
        : null;
    const nextPasswordError =
      password.length === 0 ? strings.signIn.passwordRequired : null;

    setIdentifierError(nextIdentifierError);
    setPasswordError(nextPasswordError);
    setFormError(null);

    if (nextIdentifierError || nextPasswordError) return;

    setSubmitting(true);
    try {
      let emailToUse = trimmedIdentifier;

      // Resolve username → email via find_user RPC
      if (kind === 'username') {
        const { data, error: rpcError } = await supabase.rpc('find_user', {
          username: trimmedIdentifier,
        });
        if (rpcError || !data || data.length === 0) {
          setFormError(strings.signIn.usernameNotFound);
          return;
        }
        emailToUse = data[0].user_id; // find_user returns user_id; we need email
        // find_user only returns user_id and display_name per the DB type contract.
        // Username login requires either a dedicated RPC that returns the email, or
        // a different sign-in approach. Until that RPC exists, show a clear error.
        setFormError(strings.signIn.usernameNotFound);
        return;
      }

      const { error } = await supabase.auth.signInWithPassword({
        email: emailToUse,
        password,
      });

      if (error) {
        setFormError(signInErrorMessage(error, 'email'));
        return;
      }

      // Persist or clear saved login
      if (saveLogin) {
        await AsyncStorage.setItem(SAVED_LOGIN_KEY, trimmedIdentifier);
      } else {
        await AsyncStorage.removeItem(SAVED_LOGIN_KEY);
      }
    } catch (error) {
      setFormError(signInErrorMessage(error, kind === 'username' ? 'username' : 'email'));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: theme.colors.bg.app }}
      contentContainerStyle={[
        styles.content,
        {
          paddingTop: insets.top + (height > 700 ? 64 : 32),
          paddingBottom: insets.bottom + theme.space[6],
          paddingHorizontal: theme.space[6],
        },
      ]}
      keyboardShouldPersistTaps="handled"
    >
      <View style={styles.column}>
        <Text style={[textStyle(theme.typeTokens.display), { color: theme.colors.brand.primary }]}>
          DoloGram
        </Text>

        <Text
          style={[
            textStyle(theme.typeTokens.titleLg),
            { color: theme.colors.text.primary, marginTop: theme.space[8] },
          ]}
          accessibilityRole="header"
        >
          {strings.signIn.title}
        </Text>

        <View style={{ marginTop: theme.space[6], width: '100%' }}>
          <TextField
            label={strings.signIn.emailOrUsername}
            value={identifier}
            onChangeText={(text) => {
              setIdentifier(text);
              if (identifierError) setIdentifierError(null);
            }}
            error={identifierError ?? undefined}
            keyboardType="email-address"
            autoComplete="email"
            textContentType="emailAddress"
            autoCapitalize="none"
            autoCorrect={false}
            returnKeyType="next"
            editable={!submitting}
          />

          <View style={{ height: theme.space[4] }} />

          <TextField
            label={strings.signIn.password}
            value={password}
            onChangeText={(text) => {
              setPassword(text);
              if (passwordError) setPasswordError(null);
            }}
            error={passwordError ?? undefined}
            secureTextEntry={!showPassword}
            autoComplete="current-password"
            textContentType="password"
            autoCapitalize="none"
            autoCorrect={false}
            returnKeyType="go"
            onSubmitEditing={() => {
              void handleSignIn();
            }}
            editable={!submitting}
            trailing={
              <IconButton
                iconName={showPassword ? 'action.hidePassword' : 'action.showPassword'}
                accessibilityLabel={
                  showPassword ? strings.action.hidePassword : strings.action.showPassword
                }
                onPress={() => setShowPassword((visible) => !visible)}
              />
            }
          />

          <View style={{ height: theme.space[2] }} />

          <SwitchRow
            label={strings.signIn.saveLogin}
            value={saveLogin}
            onValueChange={setSaveLogin}
            disabled={submitting}
          />
        </View>

        <View style={{ marginTop: theme.space[4], width: '100%' }}>
          <Button
            label={strings.signIn.title}
            variant="primary"
            fullWidth
            loading={submitting}
            disabled={offline}
            onPress={() => {
              void handleSignIn();
            }}
          />
        </View>

        {formError ? (
          <Text
            style={[
              textStyle(theme.typeTokens.bodySm),
              { color: theme.colors.error.text, marginTop: theme.space[4], textAlign: 'center' },
            ]}
            accessibilityRole="alert"
          >
            {formError}
          </Text>
        ) : null}

        {offline ? (
          <Text
            style={[
              textStyle(theme.typeTokens.bodySm),
              { color: theme.colors.text.secondary, marginTop: theme.space[4], textAlign: 'center' },
            ]}
          >
            {strings.common.noConnection}
          </Text>
        ) : null}

        <Pressable
          onPress={() => router.push('/forgot-password')}
          accessibilityRole="link"
          accessibilityLabel={strings.signIn.forgot}
          style={{ marginTop: theme.space[2], minHeight: 48, justifyContent: 'center' }}
        >
          <Text
            style={[
              textStyle(theme.typeTokens.bodySm),
              { color: theme.colors.text.secondary, textAlign: 'center' },
            ]}
          >
            {strings.signIn.forgot}
          </Text>
        </Pressable>

        <Pressable
          onPress={() => router.push('/sign-up')}
          accessibilityRole="link"
          accessibilityLabel={strings.signIn.createAccount}
          style={{ minHeight: 48, justifyContent: 'center' }}
        >
          <Text
            style={[
              textStyle(theme.typeTokens.bodySm),
              { color: theme.colors.brand.primary, textAlign: 'center' },
            ]}
          >
            {strings.signIn.createAccount}
          </Text>
        </Pressable>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: { flexGrow: 1, alignItems: 'center' },
  column: { width: '100%', maxWidth: 400, alignItems: 'center' },
});
