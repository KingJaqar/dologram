/**
 * CMP-15: Bottom sheet — animated translateY with PanResponder, scrim, back-button close.
 * 12.6, D-95
 */
import React, { useEffect, useRef } from 'react';
import {
  Animated,
  BackHandler,
  Modal,
  PanResponder,
  Pressable,
  StyleSheet,
  View,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import { useTheme } from '../theme/ThemeProvider';

export interface BottomSheetProps {
  visible: boolean;
  onClose: () => void;
  children: React.ReactNode;
  style?: StyleProp<ViewStyle>;
}

const HANDLE_HEIGHT = 4;
const SHEET_MAX_HEIGHT = '90%';

export function BottomSheet({
  visible,
  onClose,
  children,
  style,
}: BottomSheetProps) {
  const theme = useTheme();
  const c = theme.colors;

  const translateYRef = useRef<Animated.Value | null>(null);
  const scrimOpacityRef = useRef<Animated.Value | null>(null);
  if (translateYRef.current === null) {
    translateYRef.current = new Animated.Value(600);
  }
  if (scrimOpacityRef.current === null) {
    scrimOpacityRef.current = new Animated.Value(0);
  }
  const translateY = translateYRef.current;
  const scrimOpacity = scrimOpacityRef.current;

  // Animate in/out
  useEffect(() => {
    if (visible) {
      Animated.parallel([
        Animated.timing(translateY, {
          toValue: 0,
          duration: theme.duration('modal'),
          useNativeDriver: true,
        }),
        Animated.timing(scrimOpacity, {
          toValue: 1,
          duration: theme.duration('modal'),
          useNativeDriver: true,
        }),
      ]).start();
    } else {
      Animated.parallel([
        Animated.timing(translateY, {
          toValue: 600,
          duration: theme.duration('fast'),
          useNativeDriver: true,
        }),
        Animated.timing(scrimOpacity, {
          toValue: 0,
          duration: theme.duration('fast'),
          useNativeDriver: true,
        }),
      ]).start();
    }
  }, [visible, translateY, scrimOpacity, theme]);

  // Android back button
  useEffect(() => {
    if (!visible) return;
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      onClose();
      return true;
    });
    return () => sub.remove();
  }, [visible, onClose]);

  // Pan responder for drag-to-dismiss
  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: (_, gs) => gs.dy > 10,
      onPanResponderMove: (_, gs) => {
        if (gs.dy > 0) translateY.setValue(gs.dy);
      },
      onPanResponderRelease: (_, gs) => {
        if (gs.dy > 100 || gs.vy > 0.5) {
          onClose();
        } else {
          Animated.spring(translateY, {
            toValue: 0,
            useNativeDriver: true,
          }).start();
        }
      },
    }),
  ).current;

  return (
    <Modal
      visible={visible}
      transparent
      animationType="none"
      statusBarTranslucent
      onRequestClose={onClose}
      accessibilityViewIsModal
    >
      {/* Scrim */}
      <Animated.View
        style={[StyleSheet.absoluteFill, { backgroundColor: c.scrim, opacity: scrimOpacity }]}
        pointerEvents="none"
      />
      <Pressable
        style={[StyleSheet.absoluteFill, { justifyContent: 'flex-end' }]}
        onPress={onClose}
        accessibilityLabel="Close"
        accessibilityRole="button"
      >
        {/* Sheet */}
        <Animated.View
          style={[
            styles.sheet,
            {
              backgroundColor: c.bg.elevated,
              borderTopLeftRadius: theme.radius.xl,
              borderTopRightRadius: theme.radius.xl,
              elevation: theme.elevation[3].android,
              transform: [{ translateY }],
            },
            style,
          ]}
          {...panResponder.panHandlers}
        >
          {/* Handle */}
          <View style={styles.handleRow} pointerEvents="none">
            <View
              style={[
                styles.handle,
                { backgroundColor: c.separator, borderRadius: HANDLE_HEIGHT / 2 },
              ]}
            />
          </View>
          {/* Content area — stopPropagation so taps don't fall through to scrim */}
          <Pressable onPress={(e) => e.stopPropagation()}>
            {children}
          </Pressable>
        </Animated.View>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  sheet: {
    maxHeight: SHEET_MAX_HEIGHT,
  },
  handleRow: {
    alignItems: 'center',
    paddingTop: 12,
    paddingBottom: 8,
  },
  handle: {
    width: 32,
    height: HANDLE_HEIGHT,
  },
});
