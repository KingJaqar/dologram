/** Queue change notifications used by the chat screen to repaint LS-2 status captions. */
const listeners = new Set<() => void>();

export function subscribeQueueChange(listener: () => void): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function notifyQueueChange(): void {
  for (const listener of listeners) listener();
}
