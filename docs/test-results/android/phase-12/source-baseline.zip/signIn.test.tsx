/**
 * AND-01 Sign-in render tests (Phase 4 Step 8, T-10 UI part).
 * - Offline: Sign in is disabled and "No connection" is shown (F1 Offline).
 * - Invalid email: the field error appears and nothing is sent (D-116).
 * - Blank password: refused before sending (plan step 4).
 * - A 400 from Auth shows the single wrong-credentials message (AND-01).
 */
import React from 'react';
import { fireEvent, render, waitFor } from '@testing-library/react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { strings } from '@dologram/shared';
import { ThemeProvider } from '../theme/ThemeProvider';
import { useNetState } from '../net/netState';
import { supabase } from '../lib/supabase';
import SignInScreen from '../../app/sign-in';

jest.mock('../lib/supabase', () => ({
  supabase: { auth: { signInWithPassword: jest.fn() } },
}));

jest.mock('../net/netState', () => ({
  useNetState: jest.fn(),
}));

jest.mock('expo-router', () => ({
  useRouter: jest.fn(() => ({ push: jest.fn(), replace: jest.fn() })),
}));

const mockSignInWithPassword = supabase.auth.signInWithPassword as jest.Mock;
const mockUseNetState = useNetState as jest.Mock;

const initialMetrics = {
  frame: { x: 0, y: 0, width: 400, height: 800 },
  insets: { top: 0, left: 0, right: 0, bottom: 0 },
};

function Wrapper({ children }: { children: React.ReactNode }) {
  return (
    <SafeAreaProvider initialMetrics={initialMetrics}>
      <ThemeProvider>{children}</ThemeProvider>
    </SafeAreaProvider>
  );
}

function signInButton(screen: ReturnType<typeof render>) {
  return screen.getByRole('button', { name: strings.signIn.title });
}

describe('AND-01 Sign in', () => {
  beforeEach(() => {
    mockSignInWithPassword.mockReset();
    mockUseNetState.mockReturnValue({
      isConnected: true,
      type: 'wifi',
      cellularGeneration: null,
    });
  });

  test('offline: Sign in is disabled and "No connection" is shown', () => {
    mockUseNetState.mockReturnValue({
      isConnected: false,
      type: 'none',
      cellularGeneration: null,
    });

    const screen = render(<SignInScreen />, { wrapper: Wrapper });

    expect(signInButton(screen).props.accessibilityState?.disabled).toBe(true);
    expect(screen.getByText(strings.common.noConnection)).toBeTruthy();
  });

  test('an invalid email shows the field error and sends nothing', async () => {
    const screen = render(<SignInScreen />, { wrapper: Wrapper });

    fireEvent.changeText(screen.getByLabelText(strings.signIn.email), 'not-an-email');
    fireEvent.changeText(screen.getByLabelText(strings.signIn.password), 'a-password');
    fireEvent.press(signInButton(screen));

    await waitFor(() => {
      expect(screen.getByText(strings.signIn.invalidEmail)).toBeTruthy();
    });
    expect(mockSignInWithPassword).not.toHaveBeenCalled();
  });

  test('a blank password is refused before sending', async () => {
    const screen = render(<SignInScreen />, { wrapper: Wrapper });

    fireEvent.changeText(screen.getByLabelText(strings.signIn.email), 'user@example.com');
    fireEvent.press(signInButton(screen));

    await waitFor(() => {
      expect(screen.getByText(strings.signIn.passwordRequired)).toBeTruthy();
    });
    expect(mockSignInWithPassword).not.toHaveBeenCalled();
  });

  test('a 400 from Auth shows the single wrong-credentials message', async () => {
    mockSignInWithPassword.mockResolvedValue({ data: null, error: { status: 400 } });

    const screen = render(<SignInScreen />, { wrapper: Wrapper });

    fireEvent.changeText(screen.getByLabelText(strings.signIn.email), 'user@example.com');
    fireEvent.changeText(screen.getByLabelText(strings.signIn.password), 'a-password');
    fireEvent.press(signInButton(screen));

    await waitFor(() => {
      expect(screen.getByText(strings.signIn.wrongCredentials)).toBeTruthy();
    });
  });

  test('a 429 from Auth shows the rate-limit message', async () => {
    mockSignInWithPassword.mockResolvedValue({ data: null, error: { status: 429 } });

    const screen = render(<SignInScreen />, { wrapper: Wrapper });

    fireEvent.changeText(screen.getByLabelText(strings.signIn.email), 'user@example.com');
    fireEvent.changeText(screen.getByLabelText(strings.signIn.password), 'a-password');
    fireEvent.press(signInButton(screen));

    await waitFor(() => {
      expect(screen.getByText(strings.signIn.tooManyAttempts)).toBeTruthy();
    });
  });
});
