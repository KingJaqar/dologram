/**
 * AND-03: chat list (M2-08, F2, D-44, D-94).
 *
 * The list reads the local cache in one query (D-44), shows the D-94 order with unread counts and
 * mute icons, leaves archived chats to AND-04, and carries the CMP-13 offline banner and Low
 * Signal chip. Pull to refresh runs a resync (6.4). Row actions (archive, mute, folders) are F9
 * and arrive with Phase 14.
 */
import React, { useCallback, useEffect, useRef } from 'react';
import { FlatList, RefreshControl, StyleSheet, View } from 'react-native';
import { useRouter } from 'expo-router';
import { strings, type ChatListItem } from '@dologram/shared';
import { TopBar } from '../../../src/components/TopBar';
import { ChatRow, ChatRowSkeleton, ArchivedRow } from '../../../src/components/ChatRow';
import { LowSignalChip, OfflineBanner } from '../../../src/components/ConnectionBanner';
import { FolderTabs } from '../../../src/components/FolderTabs';
import { EmptyState, ErrorState } from '../../../src/components/EmptyState';
import { setChatsTabReselectHandler } from '../../../src/components/TabBar';
import { useToast } from '../../../src/components/Toast';
import { useChatList } from '../../../src/chatList/useChatList';
import { useNetState } from '../../../src/net/netState';
import { useForceLowSignalMode } from '../../../src/net/lowSignalPreferences';
import { isLowSignalActive } from '../../../src/net/lowSignal';
import { useTheme } from '../../../src/theme/ThemeProvider';

const SKELETON_ROWS = 8;

export default function ChatsScreen() {
  const theme = useTheme();
  const c = theme.colors;
  const router = useRouter();
  const net = useNetState();
  const forceLowSignal = useForceLowSignalMode();
  const { showToast } = useToast();
  const { active, archived, loading, error, refreshing, reload, refresh } = useChatList();
  const listRef = useRef<FlatList<ChatListItem>>(null);

  // CMP-32: a tap on Chats while it is active scrolls the list to the top.
  useEffect(() => {
    setChatsTabReselectHandler(() => {
      listRef.current?.scrollToOffset({ offset: 0, animated: true });
    });
    return () => setChatsTabReselectHandler(null);
  }, []);

  // CMP-09 Error: a failed read keeps the cached list and reports it once with Retry.
  useEffect(() => {
    if (!error || active.length === 0) return;
    showToast({
      message: strings.common.couldNotLoad,
      actionLabel: strings.common.retry,
      onAction: () => void reload(),
    });
  }, [error, active.length, showToast, reload]);

  const openChat = useCallback(
    (chatId: string) => router.push({ pathname: '/chat/[chatId]', params: { chatId } }),
    [router],
  );

  const lowSignal = isLowSignalActive(net, forceLowSignal);

  return (
    <View style={[styles.screen, { backgroundColor: c.bg.app }]}>
      <TopBar
        title="DoloGram"
        wordmark
        right={
          lowSignal ? (
            <LowSignalChip onPress={() => router.navigate('/(main)/(tabs)/settings')} />
          ) : undefined
        }
      />

      {net.isConnected ? null : <OfflineBanner />}

      <FolderTabs
        folders={[]}
        activeId={null}
        onSelect={() => {}}
        onOpenFolders={() => router.push('/folders')}
      />

      {archived.length > 0 ? (
        <ArchivedRow count={archived.length} onPress={() => router.push('/archive')} />
      ) : null}

      {loading ? (
        <View accessible accessibilityLabel="Loading">
          {Array.from({ length: SKELETON_ROWS }, (_, index) => (
            <ChatRowSkeleton key={index} />
          ))}
        </View>
      ) : error && active.length === 0 ? (
        <ErrorState onRetry={() => void reload()} />
      ) : (
        <FlatList
          ref={listRef}
          data={active}
          keyExtractor={(item) => item.chatId}
          renderItem={({ item }) => <ChatRow item={item} onPress={openChat} />}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={() => void refresh()}
              tintColor={c.brand.primary}
              colors={[c.brand.primary]}
            />
          }
          ListEmptyComponent={
            <EmptyState
              title={strings.chatList.emptyTitle}
              message={strings.chatList.emptyBody}
            />
          }
          contentContainerStyle={active.length === 0 ? styles.emptyContent : undefined}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  emptyContent: { flexGrow: 1 },
});
